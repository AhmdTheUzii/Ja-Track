/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.JaTrack.model;

import java.util.Date;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Lenovo-PC
 */
public class ProduksiTest {
    
    public ProduksiTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getIdProduksi method, of class Produksi.
     */
    @Test
    public void testGetIdProduksi() {
        System.out.println("getIdProduksi");
        Produksi instance = new Produksi();
        int expResult = 0;
        int result = instance.getIdProduksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdProduksi method, of class Produksi.
     */
    @Test
    public void testSetIdProduksi() {
        System.out.println("setIdProduksi");
        int idProduksi = 0;
        Produksi instance = new Produksi();
        instance.setIdProduksi(idProduksi);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTanggalProduksi method, of class Produksi.
     */
    @Test
    public void testGetTanggalProduksi() {
        System.out.println("getTanggalProduksi");
        Produksi instance = new Produksi();
        Date expResult = null;
        Date result = instance.getTanggalProduksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setTanggalProduksi method, of class Produksi.
     */
    @Test
    public void testSetTanggalProduksi() {
        System.out.println("setTanggalProduksi");
        Date tanggalProduksi = null;
        Produksi instance = new Produksi();
        instance.setTanggalProduksi(tanggalProduksi);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHasilProduksi method, of class Produksi.
     */
    @Test
    public void testGetHasilProduksi() {
        System.out.println("getHasilProduksi");
        Produksi instance = new Produksi();
        String expResult = "";
        String result = instance.getHasilProduksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHasilProduksi method, of class Produksi.
     */
    @Test
    public void testSetHasilProduksi() {
        System.out.println("setHasilProduksi");
        String hasilProduksi = "";
        Produksi instance = new Produksi();
        instance.setHasilProduksi(hasilProduksi);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getKeterangan method, of class Produksi.
     */
    @Test
    public void testGetKeterangan() {
        System.out.println("getKeterangan");
        Produksi instance = new Produksi();
        String expResult = "";
        String result = instance.getKeterangan();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setKeterangan method, of class Produksi.
     */
    @Test
    public void testSetKeterangan() {
        System.out.println("setKeterangan");
        String keterangan = "";
        Produksi instance = new Produksi();
        instance.setKeterangan(keterangan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDetailBahan method, of class Produksi.
     */
    @Test
    public void testGetDetailBahan() {
        System.out.println("getDetailBahan");
        Produksi instance = new Produksi();
        List<DetailProduksi> expResult = null;
        List<DetailProduksi> result = instance.getDetailBahan();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setDetailBahan method, of class Produksi.
     */
    @Test
    public void testSetDetailBahan() {
        System.out.println("setDetailBahan");
        List<DetailProduksi> detailBahan = null;
        Produksi instance = new Produksi();
        instance.setDetailBahan(detailBahan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of addDetailBahan method, of class Produksi.
     */
    @Test
    public void testAddDetailBahan() {
        System.out.println("addDetailBahan");
        DetailProduksi detail = null;
        Produksi instance = new Produksi();
        instance.addDetailBahan(detail);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
