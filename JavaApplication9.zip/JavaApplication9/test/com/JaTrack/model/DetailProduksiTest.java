/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.JaTrack.model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Lenovo-PC
 */
public class DetailProduksiTest {
    
    public DetailProduksiTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getIdDetail method, of class DetailProduksi.
     */
    @Test
    public void testGetIdDetail() {
        System.out.println("getIdDetail");
        DetailProduksi instance = new DetailProduksi();
        int expResult = 0;
        int result = instance.getIdDetail();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdDetail method, of class DetailProduksi.
     */
    @Test
    public void testSetIdDetail() {
        System.out.println("setIdDetail");
        int idDetail = 0;
        DetailProduksi instance = new DetailProduksi();
        instance.setIdDetail(idDetail);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIdProduksi method, of class DetailProduksi.
     */
    @Test
    public void testGetIdProduksi() {
        System.out.println("getIdProduksi");
        DetailProduksi instance = new DetailProduksi();
        int expResult = 0;
        int result = instance.getIdProduksi();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdProduksi method, of class DetailProduksi.
     */
    @Test
    public void testSetIdProduksi() {
        System.out.println("setIdProduksi");
        int idProduksi = 0;
        DetailProduksi instance = new DetailProduksi();
        instance.setIdProduksi(idProduksi);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getIdBarang method, of class DetailProduksi.
     */
    @Test
    public void testGetIdBarang() {
        System.out.println("getIdBarang");
        DetailProduksi instance = new DetailProduksi();
        int expResult = 0;
        int result = instance.getIdBarang();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setIdBarang method, of class DetailProduksi.
     */
    @Test
    public void testSetIdBarang() {
        System.out.println("setIdBarang");
        int idBarang = 0;
        DetailProduksi instance = new DetailProduksi();
        instance.setIdBarang(idBarang);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNamaBarang method, of class DetailProduksi.
     */
    @Test
    public void testGetNamaBarang() {
        System.out.println("getNamaBarang");
        DetailProduksi instance = new DetailProduksi();
        String expResult = "";
        String result = instance.getNamaBarang();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setNamaBarang method, of class DetailProduksi.
     */
    @Test
    public void testSetNamaBarang() {
        System.out.println("setNamaBarang");
        String namaBarang = "";
        DetailProduksi instance = new DetailProduksi();
        instance.setNamaBarang(namaBarang);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getJumlahDigunakan method, of class DetailProduksi.
     */
    @Test
    public void testGetJumlahDigunakan() {
        System.out.println("getJumlahDigunakan");
        DetailProduksi instance = new DetailProduksi();
        int expResult = 0;
        int result = instance.getJumlahDigunakan();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setJumlahDigunakan method, of class DetailProduksi.
     */
    @Test
    public void testSetJumlahDigunakan() {
        System.out.println("setJumlahDigunakan");
        int jumlahDigunakan = 0;
        DetailProduksi instance = new DetailProduksi();
        instance.setJumlahDigunakan(jumlahDigunakan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSatuan method, of class DetailProduksi.
     */
    @Test
    public void testGetSatuan() {
        System.out.println("getSatuan");
        DetailProduksi instance = new DetailProduksi();
        String expResult = "";
        String result = instance.getSatuan();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setSatuan method, of class DetailProduksi.
     */
    @Test
    public void testSetSatuan() {
        System.out.println("setSatuan");
        String satuan = "";
        DetailProduksi instance = new DetailProduksi();
        instance.setSatuan(satuan);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
