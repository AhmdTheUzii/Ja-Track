package com.JaTrack.model;


public class Distributor {
    private int idDistributor;
    private String namaDistributor;
    private String alamat;
    private String noTelepon;
    private String kontakPerson;
    private String jenisBarang;
    
    // Constructor kosong
    public Distributor() {
    }
    
    // Constructor dengan parameter
    public Distributor(int idDistributor, String namaDistributor, String alamat, 
                      String noTelepon, String kontakPerson, String jenisBarang) {
        this.idDistributor = idDistributor;
        this.namaDistributor = namaDistributor;
        this.alamat = alamat;
        this.noTelepon = noTelepon;
        this.kontakPerson = kontakPerson;
        this.jenisBarang = jenisBarang;
    }
    
    // Getter dan Setter
    public int getIdDistributor() {
        return idDistributor;
    }
    
    public void setIdDistributor(int idDistributor) {
        this.idDistributor = idDistributor;
    }
    
    public String getNamaDistributor() {
        return namaDistributor;
    }
    
    public void setNamaDistributor(String namaDistributor) {
        this.namaDistributor = namaDistributor;
    }
    
    public String getAlamat() {
        return alamat;
    }
    
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }
    
    public String getNoTelepon() {
        return noTelepon;
    }
    
    public void setNoTelepon(String noTelepon) {
        this.noTelepon = noTelepon;
    }
    
    public String getKontakPerson() {
        return kontakPerson;
    }
    
    public void setKontakPerson(String kontakPerson) {
        this.kontakPerson = kontakPerson;
    }
    
    public String getJenisBarang() {
        return jenisBarang;
    }
    
    public void setJenisBarang(String jenisBarang) {
        this.jenisBarang = jenisBarang;
    }
}