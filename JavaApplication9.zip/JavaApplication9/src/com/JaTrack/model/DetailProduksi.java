package com.JaTrack.model;

public class DetailProduksi {
    private int idDetail;
    private int idProduksi;
    private int idBarang;
    private String namaBarang;
    private int jumlahDigunakan;
    private String satuan;
    
    public DetailProduksi() {
    }
    
    public DetailProduksi(int idBarang, String namaBarang, int jumlahDigunakan, String satuan) {
        this.idBarang = idBarang;
        this.namaBarang = namaBarang;
        this.jumlahDigunakan = jumlahDigunakan;
        this.satuan = satuan;
    }
    
    // Getters and Setters
    public int getIdDetail() {
        return idDetail;
    }
    
    public void setIdDetail(int idDetail) {
        this.idDetail = idDetail;
    }
    
    public int getIdProduksi() {
        return idProduksi;
    }
    
    public void setIdProduksi(int idProduksi) {
        this.idProduksi = idProduksi;
    }
    
    public int getIdBarang() {
        return idBarang;
    }
    
    public void setIdBarang(int idBarang) {
        this.idBarang = idBarang;
    }
    
    public String getNamaBarang() {
        return namaBarang;
    }
    
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }
    
    public int getJumlahDigunakan() {
        return jumlahDigunakan;
    }
    
    public void setJumlahDigunakan(int jumlahDigunakan) {
        this.jumlahDigunakan = jumlahDigunakan;
    }
    
    public String getSatuan() {
        return satuan;
    }
    
    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }
}