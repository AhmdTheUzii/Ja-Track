package com.JaTrack.model;

import java.util.Date;

/**
 * Model untuk Barang Keluar (Pengiriman ke Customer)
 */
public class BarangKeluar {
    private int idKeluar;
    private Date tanggalKeluar;
    private int idProduksi;
    private String namaBarang;
    private int jumlah;
    private String satuan;
    private String customer;
    private String keterangan;
    
    public BarangKeluar() {
    }
    
    public BarangKeluar(Date tanggalKeluar, int idProduksi, String namaBarang, 
                        int jumlah, String satuan, String customer, String keterangan) {
        this.tanggalKeluar = tanggalKeluar;
        this.idProduksi = idProduksi;
        this.namaBarang = namaBarang;
        this.jumlah = jumlah;
        this.satuan = satuan;
        this.customer = customer;
        this.keterangan = keterangan;
    }
    
    // Getters and Setters
    public int getIdKeluar() {
        return idKeluar;
    }
    
    public void setIdKeluar(int idKeluar) {
        this.idKeluar = idKeluar;
    }
    
    public Date getTanggalKeluar() {
        return tanggalKeluar;
    }
    
    public void setTanggalKeluar(Date tanggalKeluar) {
        this.tanggalKeluar = tanggalKeluar;
    }
    
    public int getIdProduksi() {
        return idProduksi;
    }
    
    public void setIdProduksi(int idProduksi) {
        this.idProduksi = idProduksi;
    }
    
    public String getNamaBarang() {
        return namaBarang;
    }
    
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }
    
    public int getJumlah() {
        return jumlah;
    }
    
    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }
    
    public String getSatuan() {
        return satuan;
    }
    
    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }
    
    public String getCustomer() {
        return customer;
    }
    
    public void setCustomer(String customer) {
        this.customer = customer;
    }
    
    public String getKeterangan() {
        return keterangan;
    }
    
    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }

   
}