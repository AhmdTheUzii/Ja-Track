package com.JaTrack.model;

import java.util.Date;
import java.util.ArrayList;
import java.util.List;

/**
 * Model untuk Master Produksi
 * Ini class yang nyimpen info UTAMA produksi
 */
public class Produksi {
    private int idProduksi;
    private Date tanggalProduksi;
    private String hasilProduksi; // Contoh: "Celana Cargo - 50 pcs"
    private String keterangan;
    
    // List untuk nyimpen BANYAK bahan yang dipake
    private List<DetailProduksi> detailBahan;
    
    public Produksi() {
        this.detailBahan = new ArrayList<>();
    }
    
    public Produksi(int idProduksi, Date tanggalProduksi, String hasilProduksi, String keterangan) {
        this.idProduksi = idProduksi;
        this.tanggalProduksi = tanggalProduksi;
        this.hasilProduksi = hasilProduksi;
        this.keterangan = keterangan;
        this.detailBahan = new ArrayList<>();
    }
    
    // Getters and Setters
    public int getIdProduksi() {
        return idProduksi;
    }
    
    public void setIdProduksi(int idProduksi) {
        this.idProduksi = idProduksi;
    }
    
    public Date getTanggalProduksi() {
        return tanggalProduksi;
    }
    
    public void setTanggalProduksi(Date tanggalProduksi) {
        this.tanggalProduksi = tanggalProduksi;
    }
    
    public String getHasilProduksi() {
        return hasilProduksi;
    }
    
    public void setHasilProduksi(String hasilProduksi) {
        this.hasilProduksi = hasilProduksi;
    }
    
    public String getKeterangan() {
        return keterangan;
    }
    
    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
    
    public List<DetailProduksi> getDetailBahan() {
        return detailBahan;
    }
    
    public void setDetailBahan(List<DetailProduksi> detailBahan) {
        this.detailBahan = detailBahan;
    }
    
    public void addDetailBahan(DetailProduksi detail) {
        this.detailBahan.add(detail);
    }
}


/**
 * Model untuk Detail Bahan yang Digunakan
 */
