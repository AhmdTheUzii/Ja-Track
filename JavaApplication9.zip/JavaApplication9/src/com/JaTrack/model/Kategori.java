package com.JaTrack.model;


public class Kategori {
    // Variabel untuk nyimpen data (sesuai kolom di database)
    private int idKategori;
    private String kodeKategori;
    private String namaKategori;
    private String deskripsi;
    
    // Constructor kosong - wajib ada buat bikin object baru
    public Kategori() {
    }
    
    // Constructor dengan parameter - buat bikin object langsung isi data
    public Kategori(int idKategori, String kodeKategori, String namaKategori, String deskripsi) {
        this.idKategori = idKategori;
        this.kodeKategori = kodeKategori;
        this.namaKategori = namaKategori;
        this.deskripsi = deskripsi;
    }
    
    // === GETTER (Ambil data) ===
    public int getIdKategori() {
        return idKategori;
    }
    
    public String getKodeKategori() {
        return kodeKategori;
    }
    
    public String getNamaKategori() {
        return namaKategori;
    }
    
    public String getDeskripsi() {
        return deskripsi;
    }
    
    // === SETTER (Isi data) ===
    public void setIdKategori(int idKategori) {
        this.idKategori = idKategori;
    }
    
    public void setKodeKategori(String kodeKategori) {
        this.kodeKategori = kodeKategori;
    }
    
    public void setNamaKategori(String namaKategori) {
        this.namaKategori = namaKategori;
    }
    
    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }
}