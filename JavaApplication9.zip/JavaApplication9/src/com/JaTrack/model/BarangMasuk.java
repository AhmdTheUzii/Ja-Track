package com.JaTrack.model;

import java.util.Date;

/**
 * Model untuk Barang Masuk (Penerimaan dari Supplier)
 */
public class BarangMasuk {
    private int idMasuk;
    private Date tanggalMasuk;
    private int idBarang;
    private String namaBarang;
    private int jumlah;
    private String satuan;
    private String supplier;
    private String keterangan;
    
    public BarangMasuk() {
    }
    
    public BarangMasuk(Date tanggalMasuk, int idBarang, String namaBarang, 
                       int jumlah, String satuan, String supplier, String keterangan) {
        this.tanggalMasuk = tanggalMasuk;
        this.idBarang = idBarang;
        this.namaBarang = namaBarang;
        this.jumlah = jumlah;
        this.satuan = satuan;
        this.supplier = supplier;
        this.keterangan = keterangan;
    }
    
    // Getters and Setters
    public int getIdMasuk() {
        return idMasuk;
    }
    
    public void setIdMasuk(int idMasuk) {
        this.idMasuk = idMasuk;
    }
    
    public Date getTanggalMasuk() {
        return tanggalMasuk;
    }
    
    public void setTanggalMasuk(Date tanggalMasuk) {
        this.tanggalMasuk = tanggalMasuk;
    }
    
    public int getIdBarang() {
        return idBarang;
    }
    
    public void setIdBarang(int idBarang) {
        this.idBarang = idBarang;
    }
    
    public String getNamaBarang() {
        return namaBarang;
    }
    
    public void setNamaBarang(String namaBarang) {
        this.namaBarang = namaBarang;
    }
    
    public int getJumlah() {
        return jumlah;
    }
    
    public void setJumlah(int jumlah) {
        this.jumlah = jumlah;
    }
    
    public String getSatuan() {
        return satuan;
    }
    
    public void setSatuan(String satuan) {
        this.satuan = satuan;
    }
    
    public String getSupplier() {
        return supplier;
    }
    
    public void setSupplier(String supplier) {
        this.supplier = supplier;
    }
    
    public String getKeterangan() {
        return keterangan;
    }
    
    public void setKeterangan(String keterangan) {
        this.keterangan = keterangan;
    }
}


