package com.JaTrack.main;

import com.JaTrack.form.FormDashboard;
import com.JaTrack.auth.FormLogin;
import com.JaTrack.util.DatabaseConnection; // ✅ Import DatabaseConnection
import java.sql.Connection;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import raven.modal.Drawer;
import raven.modal.demo.utils.UndoRedo;

public class FormManager {
    
    public static final UndoRedo<Form> FORMS = new UndoRedo<>();
    private static MainForm mainForm;
    private static JFrame frame;
    private static FormLogin formLogin;
    private static String idUser;
    
    // ✅ TAMBAHAN: Connection untuk dipake semua form
    private static Connection connection;
    
    // ✅ TAMBAHAN: Getter connection
    public static Connection getConnection() {
        if (connection == null) {
            // Ambil connection dari DatabaseConnection singleton
            connection = DatabaseConnection.getInstance().getConnection();
        }
        return connection;
    }
            
    public static void install(JFrame f) {
        frame = f;
        logout();
    }
    
    // ✅ MODIFIKASI: showForm dengan reflection untuk auto-inject connection
    public static void showForm(Form form) {
        if(form != FORMS.getCurrent()) {
            FORMS.add(form);
            form.formCheck();
            form.formOpen();
            mainForm.setForm(form);
        }
    }
    
    // ✅ TAMBAHAN: showForm by Class (untuk menu routing)
    public static void showForm(Class<? extends Form> formClass) {
        try {
            Form form = null;
            
            // Coba bikin instance dengan constructor yang punya parameter Connection
            try {
                form = formClass.getConstructor(Connection.class).newInstance(getConnection());
                System.out.println("✅ Form created with Connection: " + formClass.getSimpleName());
            } catch (NoSuchMethodException e) {
                // Kalau ga ada constructor dengan Connection, pakai default
                form = formClass.newInstance();
                System.out.println("ℹ️ Form created without Connection: " + formClass.getSimpleName());
            }
            
            // Tampilkan form
            if (form != null) {
                showForm(form);
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(frame, 
                "Error creating form: " + e.getMessage(),
                "Error",
                javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public static void undo(){
        if(FORMS.isUndoAble()) {
            Form form = FORMS.undo();
            form.formCheck();
            form.formOpen();
            mainForm.setForm(form);
            Drawer.setSelectedItemClass(form.getClass());
        }
    }
    
    public static void redo(){
         if(FORMS.isRedoAble()) {
            Form form = FORMS.redo();
            form.formCheck();
            form.formOpen();
            mainForm.setForm(form);
            Drawer.setSelectedItemClass(form.getClass());
        }
    }
    
    public static void login() {
        idUser = "";
        Drawer.installDrawer(frame, new Menu());
        Drawer.setVisible(true);
        
        frame.getContentPane().removeAll();
        frame.getContentPane().add(getMainForm());
        Drawer.setSelectedItemClass(FormDashboard.class);
        frame.revalidate();
        frame.repaint();
    }
    
    public static void logout(){
        if(idUser == null) {
            Drawer.installDrawer(frame, new Menu());
        }
        Drawer.setVisible(false);
        frame.getContentPane().removeAll();
        frame.getRootPane().getGlassPane().setVisible(false);
        mainForm = null;
        formLogin = null;
        FormLogin login = getLogin();
        login.formCheck();
        frame.getContentPane().add(login);
        frame.revalidate();
        frame.repaint();
    }
    
    public static JFrame getFrame() {
        return frame;
    }
    
    private static MainForm getMainForm() {
        if(mainForm == null) {
            mainForm = new MainForm();
        }
        return mainForm;
    }
    
    private static FormLogin getLogin() {
        if(formLogin == null) {
            formLogin = new FormLogin();
        }
        return formLogin;
    }
    
    // ✅ TAMBAHAN: Getter untuk idUser
    public static String getIdUser() {
        return idUser;
    }
    
    // ✅ TAMBAHAN: Setter untuk idUser (dipanggil pas login sukses)
    public static void setIdUser(String id) {
        idUser = id;
    }
}