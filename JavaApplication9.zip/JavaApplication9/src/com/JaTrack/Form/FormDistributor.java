package com.JaTrack.form;

import com.JaTrack.dao.DistributorDAO;
import com.JaTrack.model.Distributor;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import java.sql.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormDistributor extends Form {
    
    // Components
    private JTextField txtNama, txtAlamat, txtTelepon, txtKontak, txtJenisBarang, txtSearch;
    private JButton btnSave, btnUpdate, btnDelete, btnClear, btnSearch;
    private JTable table;
    private DefaultTableModel tableModel;
    
    private DistributorDAO dao;
    private Connection conn;
    private int selectedId = 0;
    
    public FormDistributor() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            // TODO: Ganti dengan setting database lo
            String url = "jdbc:mysql://localhost:3306/jaws_databarang"; // Ganti nama database
            String user = "root"; // Ganti username MySQL
            String pass = ""; // Ganti password MySQL
            
            conn = DriverManager.getConnection(url, user, pass);
            dao = new DistributorDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 10", "[grow]", "[]10[grow]"));
        
        // Panel Form Input
        JPanel panelForm = createFormPanel();
        add(panelForm, "wrap");
        
        // Panel Table
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow");
        
        // Load data
        loadData();
    }
    
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]10[grow][]10[grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        // Title
        JLabel lblTitle = new JLabel("Form Distributor");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        panel.add(lblTitle, "span, wrap 15");
        
        // Input fields
        txtNama = new JTextField();
        txtAlamat = new JTextField();
        txtTelepon = new JTextField();
        txtKontak = new JTextField();
        txtJenisBarang = new JTextField();
        
        // Styling
        txtNama.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Masukkan nama distributor");
        txtAlamat.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Alamat lengkap");
        txtTelepon.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "08xx-xxxx-xxxx");
        txtKontak.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Nama kontak person");
        txtJenisBarang.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: Elektronik, Bahan Baku");
        
        // Buttons
        btnSave = new JButton(" Simpan");
        btnUpdate = new JButton(" Update");
        btnDelete = new JButton(" Hapus");
        btnClear = new JButton(" Batal");
        
        btnSave.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnUpdate.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnDelete.putClientProperty(FlatClientProperties.STYLE, "background:#F44336");
        btnClear.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        // Add to panel
        panel.add(new JLabel("Nama Distributor *"));
        panel.add(txtNama, "grow");
        panel.add(new JLabel("Alamat"));
        panel.add(txtAlamat, "grow, wrap");
        
        panel.add(new JLabel("No. Telepon"));
        panel.add(txtTelepon, "grow");
        panel.add(new JLabel("Kontak Person"));
        panel.add(txtKontak, "grow, wrap");
        
        panel.add(new JLabel("Jenis Barang"));
        panel.add(txtJenisBarang, "span 3, grow, wrap 15");
        
        panel.add(btnSave, "span 2, split 4, grow");
        panel.add(btnUpdate, "grow");
        panel.add(btnDelete, "grow");
        panel.add(btnClear, "grow");
        
        // Event listeners
        btnSave.addActionListener(e -> saveData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnClear.addActionListener(e -> clearForm());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        // Search section
        JLabel lblSearch = new JLabel(" Pencarian");
        lblSearch.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        txtSearch = new JTextField();
        btnSearch = new JButton("Cari");
        
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari nama, alamat, kontak, atau jenis barang...");
        btnSearch.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        
        panel.add(lblSearch, "split 3, gap 0 10 0 0");
        panel.add(txtSearch, "grow, gap 0 10 0 0");
        panel.add(btnSearch, "wrap 10");
        
        // Table
        String[] columns = {"ID", "Nama Distributor", "Alamat", "No. Telepon", "Kontak Person", "Jenis Barang"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
        table.getColumnModel().getColumn(2).setPreferredWidth(250);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(180);
        
        table.setRowHeight(30);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, "grow");
        
        // Event
        btnSearch.addActionListener(e -> searchData());
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableClick();
            }
        });
        
        // Search on enter
        txtSearch.addActionListener(e -> searchData());
        
        return panel;
    }
    
    private void loadData() {
        tableModel.setRowCount(0);
        
        try {
            List<Distributor> list = dao.getAll();
            for (Distributor d : list) {
                tableModel.addRow(new Object[]{
                    d.getIdDistributor(),
                    d.getNamaDistributor(),
                    d.getAlamat(),
                    d.getNoTelepon(),
                    d.getKontakPerson(),
                    d.getJenisBarang()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    
    private void saveData() {
        // Validasi
        if (txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama Distributor harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtNama.requestFocus();
            return;
        }
        
        try {
            Distributor distributor = new Distributor();
            distributor.setNamaDistributor(txtNama.getText().trim());
            distributor.setAlamat(txtAlamat.getText().trim());
            distributor.setNoTelepon(txtTelepon.getText().trim());
            distributor.setKontakPerson(txtKontak.getText().trim());
            distributor.setJenisBarang(txtJenisBarang.getText().trim());
            
            if (dao.insert(distributor)) {
                JOptionPane.showMessageDialog(this, " Data berhasil disimpan!");
                clearForm();
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menyimpan data!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void updateData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan diupdate!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama Distributor harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtNama.requestFocus();
            return;
        }
        
        try {
            Distributor distributor = new Distributor();
            distributor.setIdDistributor(selectedId);
            distributor.setNamaDistributor(txtNama.getText().trim());
            distributor.setAlamat(txtAlamat.getText().trim());
            distributor.setNoTelepon(txtTelepon.getText().trim());
            distributor.setKontakPerson(txtKontak.getText().trim());
            distributor.setJenisBarang(txtJenisBarang.getText().trim());
            
            if (dao.update(distributor)) {
                JOptionPane.showMessageDialog(this, " Data berhasil diupdate!");
                clearForm();
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal mengupdate data!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void deleteData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Yakin ingin menghapus data ini?", 
            "Konfirmasi", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                if (dao.delete(selectedId)) {
                    JOptionPane.showMessageDialog(this, " Data berhasil dihapus!");
                    clearForm();
                    loadData();
                } else {
                    JOptionPane.showMessageDialog(this, " Gagal menghapus data!");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }
    
    private void searchData() {
        String keyword = txtSearch.getText().trim();
        
        if (keyword.isEmpty()) {
            loadData();
            return;
        }
        
        tableModel.setRowCount(0);
        try {
            List<Distributor> list = dao.search(keyword);
            for (Distributor d : list) {
                tableModel.addRow(new Object[]{
                    d.getIdDistributor(),
                    d.getNamaDistributor(),
                    d.getAlamat(),
                    d.getNoTelepon(),
                    d.getKontakPerson(),
                    d.getJenisBarang()
                });
            }
            
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error searching: " + e.getMessage());
        }
    }
    
    private void clearForm() {
        txtNama.setText("");
        txtAlamat.setText("");
        txtTelepon.setText("");
        txtKontak.setText("");
        txtJenisBarang.setText("");
        selectedId = 0;
        table.clearSelection();
    }
    
    private void tableClick() {
        int row = table.getSelectedRow();
        if (row != -1) {
            selectedId = (int) table.getValueAt(row, 0);
            txtNama.setText(table.getValueAt(row, 1).toString());
            txtAlamat.setText(table.getValueAt(row, 2).toString());
            txtTelepon.setText(table.getValueAt(row, 3).toString());
            txtKontak.setText(table.getValueAt(row, 4).toString());
            txtJenisBarang.setText(table.getValueAt(row, 5).toString());
        }
    }
}