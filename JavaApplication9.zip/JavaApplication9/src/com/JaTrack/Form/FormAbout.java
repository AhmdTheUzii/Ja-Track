package com.JaTrack.form;

import com.JaTrack.main.Form;
import com.JaTrack.main.Main;
import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.URI;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;

public class FormAbout extends Form {
    
    public FormAbout() {
        init();
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 0", "[center, grow]", "[grow]"));
        
        // ✅ Panel utama yang akan di-scroll
        JPanel contentPanel = new JPanel(new MigLayout("fillx, insets 40", "[center]", "[]20[]20[]20[]20[]20[]"));
        contentPanel.putClientProperty(FlatClientProperties.STYLE,
            "[light]background:@background;" +
            "[dark]background:@background;");
        
        // Main container dengan background
        JPanel mainPanel = new JPanel(new MigLayout("fill, insets 40", "[center]", "[]20[]20[]20[]20[]"));
        mainPanel.putClientProperty(FlatClientProperties.STYLE,
            "arc:25;" +
            "[light]background:lighten(@background,5%);" +
            "[dark]background:darken(@background,3%);");
        
        // Logo
        mainPanel.add(createLogoPanel(), "wrap, align center");
        
        // App Info
        mainPanel.add(createAppInfoPanel(), "wrap, align center");
        
        // Description
        mainPanel.add(createDescriptionPanel(), "wrap, align center, width 600");
        
        // Tech Stack
        mainPanel.add(createTechStackPanel(), "wrap, align center");
        
        // Team / Credits
        mainPanel.add(createTeamPanel(), "wrap, align center");
        
        // Footer with social links
        mainPanel.add(createFooterPanel(), "wrap, align center");
        
        // ✅ Add mainPanel ke contentPanel
        contentPanel.add(mainPanel);
        
        // ✅ Wrap dengan JScrollPane
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        
        add(scrollPane, "grow");
    }
    
    private JPanel createLogoPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 0", "[center]", "[]10[]"));
        
        // Logo
        JLabel lblLogo = new JLabel();
        try {
            FlatSVGIcon logo = new FlatSVGIcon("com/JaTrack/icon/LogoJaws.svg", 190, 100);
            lblLogo.setIcon(logo);
        } catch (Exception e) {
            lblLogo.setText("");
            lblLogo.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 80));
        }
        
        // App name dengan style
        JLabel lblAppName = new JLabel("JA-Track");
        lblAppName.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +20;" +
            "foreground:$black;");
        
        panel.add(lblLogo, "wrap");
        panel.add(lblAppName);
        
        return panel;
    }
    
    private JPanel createAppInfoPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 0", "[center]", "[]5[]"));
        
        // Version
        JLabel lblVersion = new JLabel("Version " + Main.APP_VERSION);
        lblVersion.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +8");
        
        // Subtitle
        JLabel lblSubtitle = new JLabel("System Mengelola Data Barang");
        lblSubtitle.putClientProperty(FlatClientProperties.STYLE,
            "font:+3;" +
            "foreground:$Label.disabledForeground;");
        
        panel.add(lblVersion, "wrap");
        panel.add(lblSubtitle);
        
        return panel;
    }
    
    private JPanel createDescriptionPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 10, fill", "[grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE,
            "arc:15;" +
            "[light]background:darken(@background,3%);" +
            "[dark]background:lighten(@background,5%);");
        
        JTextArea txtDesc = new JTextArea(
            "JA-Track adalah aplikasi manajemen inventori modern yang memudahkan " +
            "pengelolaan data barang, kategori, distributor, produksi, dan transaksi. " +
            "Dibangun dengan teknologi Java Swing dan FlatLaf untuk memberikan " +
            "pengalaman user interface yang modern dan responsif."
        );
        txtDesc.setEditable(false);
        txtDesc.setLineWrap(true);
        txtDesc.setWrapStyleWord(true);
        txtDesc.setOpaque(false);
        txtDesc.setBorder(null);
        txtDesc.putClientProperty(FlatClientProperties.STYLE,
            "font:+1");
        
        panel.add(txtDesc, "grow");
        
        return panel;
    }
    
    private JPanel createTechStackPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 10", "[center]", "[]10[]"));
        
        JLabel lblTitle = new JLabel("Built With");
        lblTitle.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +4");
        
        JPanel techGrid = new JPanel(new MigLayout("insets 5, gap 15", "[][]", "[][]"));
        
        techGrid.add(createTechBadge("Java", "", new Color(237, 116, 0)));
        techGrid.add(createTechBadge("Swing", "", new Color(0, 123, 255)), "wrap");
        techGrid.add(createTechBadge("FlatLaf", "", new Color(108, 117, 125)));
        techGrid.add(createTechBadge("MySQL", "", new Color(0, 117, 143)), "wrap");
        techGrid.add(createTechBadge("MigLayout", "", new Color(102, 187, 106)));
        techGrid.add(createTechBadge("JDBC", "", new Color(255, 152, 0)));
        
        panel.add(lblTitle, "wrap");
        panel.add(techGrid);
        
        return panel;
    }
    
    private JLabel createTechBadge(String name, String emoji, Color color) {
        JLabel badge = new JLabel(" " + emoji + " " + name + " ");
        badge.putClientProperty(FlatClientProperties.STYLE,
            "arc:8;" +
            "font:bold +1;" +
            "foreground:#FFFFFF;" +
            "background:" + String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue()) + ";");
        badge.setOpaque(true);
        badge.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        
        return badge;
    }
    
    private JPanel createTeamPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 10", "[center]", "[]10[]"));
        
        JLabel lblTitle = new JLabel("Development Team");
        lblTitle.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +4");
        
        JPanel teamGrid = new JPanel(new MigLayout("insets 0", "[center]", "[]5[]"));
        teamGrid.putClientProperty(FlatClientProperties.STYLE,
            "arc:15;" +
            "[light]background:darken(@background,3%);" +
            "[dark]background:lighten(@background,5%);");
        
        // Developer 1
        JLabel lblDev1 = new JLabel("TheGoat - Lead Developer");
        lblDev1.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +2");
        
        // Team members
        JLabel lblTeam = new JLabel("Dan Manteman - Contributors");
        lblTeam.putClientProperty(FlatClientProperties.STYLE,
            "font:+1;" +
            "foreground:$Label.disabledForeground;");
        
        teamGrid.add(lblDev1, "wrap");
        teamGrid.add(lblTeam);
        
        panel.add(lblTitle, "wrap");
        panel.add(teamGrid);
        
        return panel;
    }
    
    private JPanel createFooterPanel() {
        JPanel panel = new JPanel(new MigLayout("insets 10", "[center]", "[]10[]"));
        
        // Copyright
        JLabel lblCopyright = new JLabel("© 2025 JA-Track. All rights reserved.");
        lblCopyright.putClientProperty(FlatClientProperties.STYLE,
            "foreground:$Label.disabledForeground;");
        
        // Social Links / Contact
        JPanel socialPanel = new JPanel(new MigLayout("insets 0, gap 15", "", ""));
        
        socialPanel.add(createSocialLink("Email", "mybagbelost"));
        socialPanel.add(createSocialLink("Website", "https://jatrack.com"));
        socialPanel.add(createSocialLink("GitHub", "https://github.com/AhmdTheUzii"));
        
        panel.add(lblCopyright, "wrap");
        panel.add(socialPanel);
        
        return panel;
    }
    
    private JLabel createSocialLink(String text, String url) {
        JLabel link = new JLabel(text);
        link.putClientProperty(FlatClientProperties.STYLE,
            "foreground:$Component.accentColor;" +
            "font:+1");
        link.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Underline on hover
        link.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                link.setText("<html><u>" + text + "</u></html>");
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                link.setText(text);
            }
            
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    Desktop.getDesktop().browse(new URI(url));
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null,
                        "Could not open link: " + url,
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        
        return link;
    }
    
    @Override
    public void formOpen() {
        // Animation atau refresh data kalau perlu
    }
}