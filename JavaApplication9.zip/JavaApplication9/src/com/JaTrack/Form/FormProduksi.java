package com.JaTrack.form;

import com.JaTrack.dao.ProduksiDAO;
import com.JaTrack.dao.BarangDAO;
import com.JaTrack.model.Produksi;
import com.JaTrack.model.DetailProduksi;
import com.JaTrack.model.Barang;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormProduksi extends Form {
    
    // Components
    private JDateChooser datePicker;
    private JTextField txtHasilProduksi, txtKeterangan, txtJumlah, txtSearch;
    private JComboBox<String> cmbBarang;
    private JButton btnTambahBahan, btnHapusBahan, btnSave, btnDelete, btnClear, btnSearch;
    private JTable tableBahan, tableProduksi;
    private DefaultTableModel modelBahan, modelProduksi;
    
    private ProduksiDAO produksiDAO;
    private BarangDAO barangDAO;
    private Connection conn;
    private int selectedIdProduksi = 0;
    
    // Temporary list untuk bahan yang dipilih
    private List<Barang> listBarang;
    
    public FormProduksi() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            // TODO: Ganti dengan setting database lo
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            produksiDAO = new ProduksiDAO(conn);
            barangDAO = new BarangDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 10", "[50%][50%]", "[]10[grow]"));
        
        // Panel Kiri - Form Input
        JPanel panelLeft = createLeftPanel();
        add(panelLeft, "grow");
        
        // Panel Kanan - Tabel Produksi
        JPanel panelRight = createRightPanel();
        add(panelRight, "grow");
        
        // Load data
        loadBarangToComboBox();
        loadDataProduksi();
    }
    
    private JPanel createLeftPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[][][][grow][]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        // Title
        JLabel lblTitle = new JLabel(" Form Produksi Baru");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        panel.add(lblTitle, "wrap 15");
        
        // Section 1: Info Produksi
        JPanel panelInfo = new JPanel(new MigLayout("fill", "[]10[grow]", ""));
        panelInfo.setBorder(BorderFactory.createTitledBorder("Informasi Produksi"));
        
        datePicker = new JDateChooser();
        datePicker.setDate(new Date());
        txtHasilProduksi = new JTextField();
        txtKeterangan = new JTextField();
        
        txtHasilProduksi.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: Celana Cargo - 50 pcs");
        txtKeterangan.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Keterangan tambahan (optional)");
        
        panelInfo.add(new JLabel("Tanggal Produksi:"));
        panelInfo.add(datePicker, "grow, wrap");
        panelInfo.add(new JLabel("Hasil Produksi:"));
        panelInfo.add(txtHasilProduksi, "grow, wrap");
        panelInfo.add(new JLabel("Keterangan:"));
        panelInfo.add(txtKeterangan, "grow, wrap");
        
        panel.add(panelInfo, "grow, wrap");
        
        // Section 2: Pilih Bahan
        JPanel panelBahan = new JPanel(new MigLayout("fill", "[]10[grow][]", ""));
        panelBahan.setBorder(BorderFactory.createTitledBorder("Tambah Bahan"));
        
        cmbBarang = new JComboBox<>();
        txtJumlah = new JTextField();
        btnTambahBahan = new JButton(" Tambah");
        
        txtJumlah.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Jumlah");
        btnTambahBahan.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        
        panelBahan.add(new JLabel("Pilih Barang:"));
        panelBahan.add(cmbBarang, "grow, wrap");
        panelBahan.add(new JLabel("Jumlah:"));
        panelBahan.add(txtJumlah, "grow");
        panelBahan.add(btnTambahBahan, "wrap");
        
        panel.add(panelBahan, "grow, wrap");
        
        // Section 3: Tabel Bahan yang Dipilih
        JPanel panelTabelBahan = new JPanel(new MigLayout("fill", "[grow]", "[]5[grow]"));
        panelTabelBahan.setBorder(BorderFactory.createTitledBorder("Bahan yang Digunakan"));
        
        btnHapusBahan = new JButton(" Hapus Bahan");
        btnHapusBahan.putClientProperty(FlatClientProperties.STYLE, "background:#F44336");
        
        String[] colsBahan = {"ID", "Nama Barang", "Jumlah", "Satuan", "Stok Tersedia"};
        modelBahan = new DefaultTableModel(colsBahan, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tableBahan = new JTable(modelBahan);
        tableBahan.getColumnModel().getColumn(0).setMaxWidth(50);
        tableBahan.setRowHeight(25);
        JScrollPane scrollBahan = new JScrollPane(tableBahan);
        
        panelTabelBahan.add(btnHapusBahan, "wrap");
        panelTabelBahan.add(scrollBahan, "grow");
        
        panel.add(panelTabelBahan, "grow, wrap");
        
        // Section 4: Buttons
        JPanel panelButtons = new JPanel(new MigLayout("fill", "[grow][grow][grow]", ""));
        
        btnSave = new JButton("Simpan Produksi");
        btnClear = new JButton(" Batal");
        
        btnSave.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnClear.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        panelButtons.add(btnSave, "grow");
        panelButtons.add(btnClear, "grow");
        
        panel.add(panelButtons, "grow");
        
        // Event Listeners
        btnTambahBahan.addActionListener(e -> tambahBahanKeList());
        btnHapusBahan.addActionListener(e -> hapusBahanDariList());
        btnSave.addActionListener(e -> saveProduksi());
        btnClear.addActionListener(e -> clearForm());
        
        return panel;
    }
    
    private JPanel createRightPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        // Title
        JLabel lblTitle = new JLabel(" Riwayat Produksi");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        
        // Search
        txtSearch = new JTextField();
        btnSearch = new JButton(" Cari");
        btnDelete = new JButton(" Hapus");
        
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari hasil produksi...");
        btnSearch.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        btnDelete.putClientProperty(FlatClientProperties.STYLE, "background:#F44336");
        
        panel.add(lblTitle, "wrap 10");
        panel.add(txtSearch, "split 3, grow");
        panel.add(btnSearch);
        panel.add(btnDelete, "wrap 10");
        
        // Table Produksi
        String[] colsProduksi = {"ID", "Tanggal", "Hasil Produksi", "Keterangan"};
        modelProduksi = new DefaultTableModel(colsProduksi, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tableProduksi = new JTable(modelProduksi);
        tableProduksi.getColumnModel().getColumn(0).setMaxWidth(50);
        tableProduksi.setRowHeight(30);
        JScrollPane scrollProduksi = new JScrollPane(tableProduksi);
        
        panel.add(scrollProduksi, "grow");
        
        // Event Listeners
        btnSearch.addActionListener(e -> searchProduksi());
        btnDelete.addActionListener(e -> deleteProduksi());
        txtSearch.addActionListener(e -> searchProduksi());
        
        tableProduksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 2) { // Double click
                    showDetailProduksi();
                }
            }
        });
        
        return panel;
    }
    
    private void loadBarangToComboBox() {
        try {
            listBarang = barangDAO.getAll();
            cmbBarang.removeAllItems();
            cmbBarang.addItem("-- Pilih Barang --");
            
            for (Barang b : listBarang) {
                cmbBarang.addItem(b.getNamaBarang() + " (Stok: " + b.getStok() + " " + b.getSatuan() + ")");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading barang: " + e.getMessage());
        }
    }
    
    private void tambahBahanKeList() {
        int selectedIndex = cmbBarang.getSelectedIndex();
        if (selectedIndex <= 0) {
            JOptionPane.showMessageDialog(this, "Pilih barang terlebih dahulu!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String jumlahStr = txtJumlah.getText().trim();
        if (jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Masukkan jumlah barang!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int jumlah = Integer.parseInt(jumlahStr);
            if (jumlah <= 0) {
                JOptionPane.showMessageDialog(this, "Jumlah harus lebih dari 0!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            Barang barang = listBarang.get(selectedIndex - 1);
            
            // Cek stok
            if (!produksiDAO.cekStok(barang.getIdBarang(), jumlah)) {
                JOptionPane.showMessageDialog(this, 
                    "Stok tidak cukup!\nStok tersedia: " + barang.getStok() + " " + barang.getSatuan(), 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            // Cek apakah barang sudah ada di list
            for (int i = 0; i < modelBahan.getRowCount(); i++) {
                int idBarang = (int) modelBahan.getValueAt(i, 0);
                if (idBarang == barang.getIdBarang()) {
                    JOptionPane.showMessageDialog(this, "Barang sudah ada dalam list!", "Peringatan", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }
            
            // Tambahkan ke tabel
            modelBahan.addRow(new Object[]{
                barang.getIdBarang(),
                barang.getNamaBarang(),
                jumlah,
                barang.getSatuan(),
                barang.getStok()
            });
            
            txtJumlah.setText("");
            cmbBarang.setSelectedIndex(0);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void hapusBahanDariList() {
        int row = tableBahan.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih bahan yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        modelBahan.removeRow(row);
    }
    
    private void saveProduksi() {
        // Validasi
        if (txtHasilProduksi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Hasil produksi harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (modelBahan.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tambahkan minimal 1 bahan!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            Produksi produksi = new Produksi();
            produksi.setTanggalProduksi(datePicker.getDate());
            produksi.setHasilProduksi(txtHasilProduksi.getText().trim());
            produksi.setKeterangan(txtKeterangan.getText().trim());
            
            // Tambahkan detail bahan
            for (int i = 0; i < modelBahan.getRowCount(); i++) {
                int idBarang = (int) modelBahan.getValueAt(i, 0);
                String namaBarang = modelBahan.getValueAt(i, 1).toString();
                int jumlah = (int) modelBahan.getValueAt(i, 2);
                String satuan = modelBahan.getValueAt(i, 3).toString();
                
                DetailProduksi detail = new DetailProduksi(idBarang, namaBarang, jumlah, satuan);
                produksi.addDetailBahan(detail);
            }
            
            // Simpan ke database (auto update stok)
            if (produksiDAO.insert(produksi)) {
                JOptionPane.showMessageDialog(this, " Produksi berhasil disimpan!Stok barang otomatis dikurangi!");
                clearForm();
                loadDataProduksi();
                loadBarangToComboBox(); // Refresh stok di combobox
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menyimpan produksi!");
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void loadDataProduksi() {
        modelProduksi.setRowCount(0);
        
        try {
            List<Produksi> list = produksiDAO.getAll();
            for (Produksi p : list) {
                modelProduksi.addRow(new Object[]{
                    p.getIdProduksi(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(p.getTanggalProduksi()),
                    p.getHasilProduksi(),
                    p.getKeterangan()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    
    private void showDetailProduksi() {
        int row = tableProduksi.getSelectedRow();
        if (row == -1) return;
        
        int idProduksi = (int) tableProduksi.getValueAt(row, 0);
        
        try {
            List<DetailProduksi> details = produksiDAO.getDetailByIdProduksi(idProduksi);
            
            StringBuilder sb = new StringBuilder();
            sb.append("Detail Bahan yang Digunakan:\n\n");
            
            for (DetailProduksi d : details) {
                sb.append("• ").append(d.getNamaBarang())
                  .append(": ").append(d.getJumlahDigunakan())
                  .append(" ").append(d.getSatuan()).append("\n");
            }
            
            JOptionPane.showMessageDialog(this, sb.toString(), "Detail Produksi", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void deleteProduksi() {
        int row = tableProduksi.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int idProduksi = (int) tableProduksi.getValueAt(row, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Hapus produksi ini? Stok barang akan dikembalikan!", 
            "Konfirmasi", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                if (produksiDAO.delete(idProduksi)) {
                    JOptionPane.showMessageDialog(this, " Data berhasil dihapus!\n🔄 Stok barang dikembalikan!");
                    loadDataProduksi();
                    loadBarangToComboBox();
                } else {
                    JOptionPane.showMessageDialog(this, " Gagal menghapus data!");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }
    
    private void searchProduksi() {
        String keyword = txtSearch.getText().trim();
        
        if (keyword.isEmpty()) {
            loadDataProduksi();
            return;
        }
        
        modelProduksi.setRowCount(0);
        try {
            List<Produksi> list = produksiDAO.search(keyword);
            for (Produksi p : list) {
                modelProduksi.addRow(new Object[]{
                    p.getIdProduksi(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(p.getTanggalProduksi()),
                    p.getHasilProduksi(),
                    p.getKeterangan()
                });
            }
            
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void clearForm() {
        datePicker.setDate(new Date());
        txtHasilProduksi.setText("");
        txtKeterangan.setText("");
        txtJumlah.setText("");
        cmbBarang.setSelectedIndex(0);
        modelBahan.setRowCount(0);
        selectedIdProduksi = 0;
        tableProduksi.clearSelection();
    }
}