package com.JaTrack.form;

import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import net.miginfocom.swing.MigLayout;

public class FormDashboard extends Form {
    
    private JLabel lblTotalBarang, lblTotalKategori, lblTotalDistributor, lblTotalTransaksi;
    private JLabel lblDateTime;
    private Timer timer;
    
    public FormDashboard() {
        init();
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 20, gap 15", "[grow][grow][grow][grow]", "[]15[]15[grow]"));
        
        // Header dengan judul dan tanggal/waktu
        add(createHeader(), "span 4, wrap");
        
        // Card Statistics (4 cards)
        add(createCard("Total Barang", "0", "manage.svg", new Color(52, 152, 219)), "grow");
        add(createCard("Total Kategori", "0", "kategori.svg", new Color(46, 204, 113)), "grow");
        add(createCard("Total Distributor", "0", "distributor.svg", new Color(155, 89, 182)), "grow");
        add(createCard("Total Transaksi", "0", "transaksi.svg", new Color(231, 76, 60)), "grow, wrap");
        
        // Panel bawah dengan 2 section
        add(createRecentActivity(), "span 2, grow");
        add(createQuickActions(), "span 2, grow");
        
        // Start timer untuk update waktu
        startTimer();
    }
    
    private JPanel createHeader() {
        JPanel panel = new JPanel(new MigLayout("fill", "[]push[]", ""));
        
        JLabel lblTitle = new JLabel("Dashboard ");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, 
            "font:bold +10");
        
        lblDateTime = new JLabel();
        lblDateTime.putClientProperty(FlatClientProperties.STYLE,
            "foreground:$Label.disabledForeground");
        updateDateTime();
        
        panel.add(lblTitle);
        panel.add(lblDateTime);
        
        return panel;
    }
    
    private JPanel createCard(String title, String value, String iconName, Color color) {
        JPanel panel = new JPanel(new MigLayout("fill, insets 20", "[]push[]", "[]10[]"));
        panel.putClientProperty(FlatClientProperties.STYLE, 
            "arc:20;" +
            "[light]background:lighten(@background,3%);" +
            "[dark]background:darken(@background,3%);");
        
        // Icon
        JLabel lblIcon = new JLabel();
        try {
            FlatSVGIcon icon = new FlatSVGIcon("com/JaTrack/icon/" + iconName, 40, 40);
            icon.setColorFilter(new FlatSVGIcon.ColorFilter(c -> color));
            lblIcon.setIcon(icon);
        } catch (Exception e) {
            lblIcon.setText("📊");
            lblIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40));
        }
        
        // Value
        JLabel lblValue = new JLabel(value);
        lblValue.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +20");
        
        // Title
        JLabel lblTitle = new JLabel(title);
        lblTitle.putClientProperty(FlatClientProperties.STYLE,
            "foreground:$Label.disabledForeground;" +
            "font:+1");
        
        panel.add(lblIcon, "wrap");
        panel.add(lblValue, "span 2, wrap");
        panel.add(lblTitle, "span 2");
        
        return panel;
    }
    
    private JPanel createRecentActivity() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE,
            "arc:20;" +
            "[light]background:lighten(@background,3%);" +
            "[dark]background:darken(@background,3%);");
        
        JLabel lblTitle = new JLabel("Aktivitas Terbaru");
        lblTitle.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +2");
        
        // List aktivitas
        JPanel activityList = new JPanel(new MigLayout("fillx, insets 0", "[grow]", "[]5[]5[]5[]5[]"));
        
        activityList.add(createActivityItem("", "Barang baru ditambahkan", "2 menit yang lalu"), "wrap");
        activityList.add(createActivityItem("", "Transaksi berhasil", "15 menit yang lalu"), "wrap");
        activityList.add(createActivityItem("", "Stok barang diperbarui", "1 jam yang lalu"), "wrap");
        activityList.add(createActivityItem("", "Kategori baru dibuat", "2 jam yang lalu"), "wrap");
        activityList.add(createActivityItem("", "Distributor ditambahkan", "3 jam yang lalu"), "wrap");
        
        JScrollPane scroll = new JScrollPane(activityList);
        scroll.setBorder(null);
        
        panel.add(lblTitle, "wrap");
        panel.add(scroll, "grow");
        
        return panel;
    }
    
    private JPanel createActivityItem(String emoji, String text, String time) {
        JPanel panel = new JPanel(new MigLayout("fillx, insets 10", "[]10[grow]push[]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE,
            "arc:10;" +
            "[light]background:darken(@background,3%);" +
            "[dark]background:lighten(@background,3%);");
        
        JLabel lblEmoji = new JLabel(emoji);
        lblEmoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        
        JLabel lblText = new JLabel(text);
        
        JLabel lblTime = new JLabel(time);
        lblTime.putClientProperty(FlatClientProperties.STYLE,
            "foreground:$Label.disabledForeground;" +
            "font:-1");
        
        panel.add(lblEmoji);
        panel.add(lblText);
        panel.add(lblTime);
        
        return panel;
    }
    
    private JPanel createQuickActions() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE,
            "arc:20;" +
            "[light]background:lighten(@background,3%);" +
            "[dark]background:darken(@background,3%);");
        
        JLabel lblTitle = new JLabel("Aksi Cepat");
        lblTitle.putClientProperty(FlatClientProperties.STYLE,
            "font:bold +2");
        
        // Grid buttons
        JPanel buttonGrid = new JPanel(new MigLayout("fill, insets 0", "[grow][grow]", "[]10[]"));
        
        buttonGrid.add(createActionButton("Tambah Barang", new Color(52, 152, 219)), "grow");
        buttonGrid.add(createActionButton("Lihat Stok", new Color(46, 204, 113)), "grow, wrap");
        
        buttonGrid.add(createActionButton("Transaksi Baru", new Color(155, 89, 182)), "grow");
        buttonGrid.add(createActionButton("Kelola Distributor", new Color(230, 126, 34)), "grow");
        
        panel.add(lblTitle, "wrap");
        panel.add(buttonGrid, "grow");
        
        return panel;
    }
    
    private JButton createActionButton(String text, Color color) {
        JButton button = new JButton(text);
        button.putClientProperty(FlatClientProperties.STYLE,
            "arc:10;" +
            "borderWidth:0;" +
            "focusWidth:0;" +
            "innerFocusWidth:0;" +
            "font:bold +1;" +
            "background:" + String.format("#%02x%02x%02x", color.getRed(), color.getGreen(), color.getBlue()) + ";" +
            "foreground:#FFFFFF");
        
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // ✅ Add action listener based on button text
        button.addActionListener(e -> handleQuickAction(text));
        
        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            Color originalColor = color;
            Color hoverColor = color.brighter();
            
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(hoverColor);
            }
            
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(originalColor);
            }
        });
        
        return button;
    }
    
    // ✅ Handle quick action button clicks
    private void handleQuickAction(String action) {
        try {
            if (action.contains("Tambah Barang")) {
                // Buka form barang
                com.JaTrack.main.FormManager.showForm(
                    com.JaTrack.main.AllForms.getForm(com.JaTrack.form.FormBarang.class)
                );
                
            } else if (action.contains("Lihat Stok")) {
                // Buka form barang dengan filter stok
                com.JaTrack.main.FormManager.showForm(
                    com.JaTrack.main.AllForms.getForm(com.JaTrack.form.FormBarang.class)
                );
                JOptionPane.showMessageDialog(this, 
                    "Menampilkan data stok barang", 
                    "Info", 
                    JOptionPane.INFORMATION_MESSAGE);
                
            } else if (action.contains("Transaksi Baru")) {
                // Buka form transaksi
                try {
                    com.JaTrack.main.FormManager.showForm(
                        com.JaTrack.main.AllForms.getForm(
                            Class.forName("com.JaTrack.form.FormTransaksi").asSubclass(com.JaTrack.main.Form.class)
                        )
                    );
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Form Transaksi belum tersedia", 
                        "Info", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
                
            } else if (action.contains("Kelola Distributor")) {
                // Buka form distributor
                try {
                    com.JaTrack.main.FormManager.showForm(
                        com.JaTrack.main.AllForms.getForm(
                            Class.forName("com.JaTrack.form.FormDistributor").asSubclass(com.JaTrack.main.Form.class)
                        )
                    );
                } catch (ClassNotFoundException ex) {
                    JOptionPane.showMessageDialog(this, 
                        "Form Distributor belum tersedia", 
                        "Info", 
                        JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
    
    private void startTimer() {
        timer = new Timer(1000, e -> updateDateTime());
        timer.start();
    }
    
    private void updateDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE, dd MMMM yyyy - HH:mm:ss");
        lblDateTime.setText(sdf.format(new Date()));
    }
    
    @Override
    public void formOpen() {
        // Load data statistik dari database
        loadStatistics();
    }
    
    private void loadStatistics() {
        // TODO: Ambil data dari database
        // Sementara pakai data dummy
        
        // Contoh update value:
        // lblTotalBarang.setText("125");
        // lblTotalKategori.setText("15");
        // lblTotalDistributor.setText("8");
        // lblTotalTransaksi.setText("342");
    }
    
    // Method untuk update statistik dari luar
    public void updateStatistic(String type, int value) {
        DecimalFormat df = new DecimalFormat("#,###");
        String formattedValue = df.format(value);
        
        // Update berdasarkan tipe
        // Implementasi sesuai kebutuhan
    }
}