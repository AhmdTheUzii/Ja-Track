package com.JaTrack.form;

import com.JaTrack.dao.BarangDAO;
import com.JaTrack.model.Barang;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import java.sql.Connection;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

/**
 * FormBarang LENGKAP dengan AUTO REFRESH
 * - Auto refresh saat form dibuka (formOpen)
 * - Manual refresh dengan button
 */
public class FormBarang extends Form {
    
    // Komponen UI
    private JTextField txtKode, txtNama, txtStok, txtHarga, txtSatuan, txtSearch;
    private JComboBox<String> cmbKategori;
    private JButton btnSave, btnUpdate, btnDelete, btnClear, btnSearch, btnRefreshKategori, btnRefresh;
    private JTable table;
    private DefaultTableModel tableModel;
    
    // Database
    private BarangDAO dao;
    private Connection conn;
    private int selectedId = 0;
    private NumberFormat currencyFormat;
    
    // ========================================
    // CONSTRUCTOR
    // ========================================
    public FormBarang() {
        this.conn = com.JaTrack.util.DatabaseConnection.getInstance().getConnection();
        this.dao = new BarangDAO(conn);
        this.currencyFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        init();
        loadKategori();
        loadData();
    }
    
    public FormBarang(Connection conn) {
        this.conn = conn;
        this.dao = new BarangDAO(conn);
        this.currencyFormat = NumberFormat.getCurrencyInstance(new Locale("id", "ID"));
        init();
        loadKategori();
        loadData();
    }
    
    // ========================================
    // ✅ AUTO REFRESH saat form dibuka
    // ========================================
    @Override
    public void formOpen() {
        System.out.println(" FormBarang dibuka, auto refresh data...");
        loadData();
        loadKategori();
    }
   
    public void refresh() {
        // Double check refresh
        loadData();
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 20", "[grow]", "[]20[grow]"));
        
        JPanel panelForm = createFormPanel();
        add(panelForm, "wrap");
        
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow");
    }
    
    // ========================================
    // PANEL FORM INPUT
    // ========================================
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]15[grow][]15[grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:darken(@background,3%)");
        
        // Title
        JLabel lblTitle = new JLabel(" Form Data Barang");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        panel.add(lblTitle, "span 4, wrap 15");
        
        // Input fields
        txtKode = new JTextField(15);
        txtNama = new JTextField(15);
        cmbKategori = new JComboBox<>();
        txtStok = new JTextField(15);
        txtHarga = new JTextField(15);
        txtSatuan = new JTextField(15);
        
        // Placeholder
        txtKode.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: BRG001");
        txtNama.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Nama barang");
        txtStok.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Jumlah stok");
        txtHarga.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Harga satuan");
        txtSatuan.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: Pcs, Kg, Unit");
        
        // Button refresh kategori
        btnRefreshKategori = new JButton("Rfr");
        btnRefreshKategori.setToolTipText("Refresh daftar kategori");
        btnRefreshKategori.addActionListener(e -> loadKategori());
        
        // Buttons
        btnSave = new JButton(" Simpan");
        btnUpdate = new JButton(" Update");
        btnDelete = new JButton(" Hapus");
        btnClear = new JButton(" Batal");
        
        btnSave.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnUpdate.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnDelete.putClientProperty(FlatClientProperties.STYLE, "background:#f44336");
        btnClear.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        // Layout
        panel.add(new JLabel("Kode Barang:"));
        panel.add(txtKode, "grow");
        panel.add(new JLabel("Nama Barang:"));
        panel.add(txtNama, "grow, wrap");
        
        panel.add(new JLabel("Kategori:"));
        panel.add(cmbKategori, "split 2, grow");
        panel.add(btnRefreshKategori, "w 40!");
        panel.add(new JLabel("Stok:"));
        panel.add(txtStok, "grow, wrap");
        
        panel.add(new JLabel("Harga:"));
        panel.add(txtHarga, "grow");
        panel.add(new JLabel("Satuan:"));
        panel.add(txtSatuan, "grow, wrap 15");
        
        panel.add(btnSave, "span 4, split 4, grow");
        panel.add(btnUpdate, "grow");
        panel.add(btnDelete, "grow");
        panel.add(btnClear, "grow");
        
        // Events
        btnSave.addActionListener(e -> saveData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnClear.addActionListener(e -> clearForm());
        
        // Validasi input angka
        txtHarga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c != '.' && c != java.awt.event.KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
        
        txtStok.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                char c = evt.getKeyChar();
                if (!Character.isDigit(c) && c != java.awt.event.KeyEvent.VK_BACK_SPACE) {
                    evt.consume();
                }
            }
        });
        
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        
        return panel;
    }
    
    // ========================================
    // PANEL TABLE dengan BUTTON REFRESH
    // ========================================
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]15[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:darken(@background,3%)");
        
        // Title
        JLabel lblTitle = new JLabel(" Daftar Barang");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        
        // Search
        txtSearch = new JTextField(20);
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari kode, nama, kategori, atau satuan...");
        btnSearch = new JButton(" Cari");
        
        // ✅ BUTTON REFRESH (Manual)
        btnRefresh = new JButton(" Refresh");
        btnRefresh.setToolTipText("Refresh data terbaru dari database");
        btnRefresh.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        btnRefresh.addActionListener(e -> {
            refreshData();
            JOptionPane.showMessageDialog(this, 
                "✅ Data berhasil di-refresh dari database!", 
                "Refresh", 
                JOptionPane.INFORMATION_MESSAGE);
        });
        
        // Layout - ada 4 komponen dalam 1 baris
        panel.add(lblTitle, "split 4");
        panel.add(txtSearch, "grow, gapleft push");
        panel.add(btnSearch);
        panel.add(btnRefresh, "wrap"); // ✅ Button refresh di sini
        
        // Table
        String[] columns = {"ID", "Kode", "Nama Barang", "Kategori", "Stok", "Harga", "Satuan"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(70);
        table.getColumnModel().getColumn(5).setPreferredWidth(120);
        table.getColumnModel().getColumn(6).setPreferredWidth(70);
        
        table.setRowHeight(30);
        table.getTableHeader().putClientProperty(FlatClientProperties.STYLE, "height:35");
        
        JScrollPane scroll = new JScrollPane(table);
        scroll.putClientProperty(FlatClientProperties.STYLE, "arc:15");
        panel.add(scroll, "grow");
        
        // Events
        btnSearch.addActionListener(e -> searchData());
        txtSearch.addActionListener(e -> searchData());
        
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    tableClick();
                }
            }
        });
        
        return panel;
    }
    
    // ========================================
    // ✅ METHOD REFRESH DATA
    // ========================================
    private void refreshData() {
        loadData();
        System.out.println(" Data barang berhasil di-refresh dari database");
    }
    
    // ========================================
    // LOAD KATEGORI - Isi dropdown
    // ========================================
    private void loadKategori() {
        if (dao == null) return;
        
        cmbKategori.removeAllItems();
        cmbKategori.addItem("-- Pilih Kategori --");
        
        List<String> kategoriList = dao.getAllKategori();
        for (String kategori : kategoriList) {
            cmbKategori.addItem(kategori);
        }
        
        System.out.println(" Kategori loaded: " + kategoriList.size() + " items");
    }
    
    // ========================================
    // LOAD DATA
    // ========================================
    private void loadData() {
        if (dao == null) return;
        
        tableModel.setRowCount(0);
        List<Barang> list = dao.getAll();
        
        for (Barang b : list) {
            Object[] row = {
                b.getIdBarang(),
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok(),
                currencyFormat.format(b.getHarga()),
                b.getSatuan()
            };
            tableModel.addRow(row);
        }
        
        System.out.println(" Data barang loaded: " + list.size() + " items");
    }
    
    // ========================================
    // SAVE DATA
    // ========================================
    private void saveData() {
        if (dao == null) {
            JOptionPane.showMessageDialog(this, "Database connection error!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Validasi
        if (txtKode.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Kode barang harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        if (txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama barang harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtNama.requestFocus();
            return;
        }
        
        if (cmbKategori.getSelectedIndex() == 0) {
            JOptionPane.showMessageDialog(this, "Kategori harus dipilih!", "Validasi", JOptionPane.WARNING_MESSAGE);
            cmbKategori.requestFocus();
            return;
        }
        
        if (txtStok.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Stok harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtStok.requestFocus();
            return;
        }
        
        if (txtHarga.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Harga harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtHarga.requestFocus();
            return;
        }
        
        if (txtSatuan.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Satuan harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtSatuan.requestFocus();
            return;
        }
        
        // Cek duplikat
        if (dao.isKodeExists(txtKode.getText().trim(), 0)) {
            JOptionPane.showMessageDialog(this, "Kode barang sudah digunakan!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        // Parse numeric
        int stok;
        double harga;
        try {
            stok = Integer.parseInt(txtStok.getText().trim());
            harga = Double.parseDouble(txtHarga.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok dan Harga harus berupa angka!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Save
        Barang barang = new Barang();
        barang.setKodeBarang(txtKode.getText().trim());
        barang.setNamaBarang(txtNama.getText().trim());
        barang.setKategori(cmbKategori.getSelectedItem().toString());
        barang.setStok(stok);
        barang.setHarga(harga);
        barang.setSatuan(txtSatuan.getText().trim());
        
        if (dao.insert(barang)) {
            JOptionPane.showMessageDialog(this, " Data barang berhasil disimpan!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, " Gagal menyimpan data!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // UPDATE DATA
    // ========================================
    private void updateData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan diupdate!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validasi
        if (txtKode.getText().trim().isEmpty() || txtNama.getText().trim().isEmpty() || 
            cmbKategori.getSelectedIndex() == 0 || txtStok.getText().trim().isEmpty() ||
            txtHarga.getText().trim().isEmpty() || txtSatuan.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua field wajib harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Cek duplikat
        if (dao.isKodeExists(txtKode.getText().trim(), selectedId)) {
            JOptionPane.showMessageDialog(this, "Kode barang sudah digunakan!", "Validasi", JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        // Parse numeric
        int stok;
        double harga;
        try {
            stok = Integer.parseInt(txtStok.getText().trim());
            harga = Double.parseDouble(txtHarga.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Stok dan Harga harus berupa angka!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Update
        Barang barang = new Barang();
        barang.setIdBarang(selectedId);
        barang.setKodeBarang(txtKode.getText().trim());
        barang.setNamaBarang(txtNama.getText().trim());
        barang.setKategori(cmbKategori.getSelectedItem().toString());
        barang.setStok(stok);
        barang.setHarga(harga);
        barang.setSatuan(txtSatuan.getText().trim());
        
        if (dao.update(barang)) {
            JOptionPane.showMessageDialog(this, " Data barang berhasil diupdate!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, " Gagal mengupdate data!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // DELETE DATA
    // ========================================
    private void deleteData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Apakah Anda yakin ingin menghapus barang ini? Data yang terhapus tidak dapat dikembalikan!", 
            "Konfirmasi Hapus", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.delete(selectedId)) {
                JOptionPane.showMessageDialog(this, " Data barang berhasil dihapus!", "Sukses", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menghapus data!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // ========================================
    // SEARCH DATA
    // ========================================
    private void searchData() {
        String keyword = txtSearch.getText().trim();
        
        if (keyword.isEmpty()) {
            loadData();
            return;
        }
        
        tableModel.setRowCount(0);
        List<Barang> list = dao.search(keyword);
        
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Data tidak ditemukan!", "Pencarian", JOptionPane.INFORMATION_MESSAGE);
        }
        
        for (Barang b : list) {
            Object[] row = {
                b.getIdBarang(),
                b.getKodeBarang(),
                b.getNamaBarang(),
                b.getKategori(),
                b.getStok(),
                currencyFormat.format(b.getHarga()),
                b.getSatuan()
            };
            tableModel.addRow(row);
        }
    }
    
    // ========================================
    // CLEAR FORM
    // ========================================
    private void clearForm() {
        txtKode.setText("");
        txtNama.setText("");
        cmbKategori.setSelectedIndex(0);
        txtStok.setText("");
        txtHarga.setText("");
        txtSatuan.setText("");
        txtSearch.setText("");
        selectedId = 0;
        
        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        
        table.clearSelection();
        txtKode.requestFocus();
    }
    
    // ========================================
    // TABLE CLICK
    // ========================================
    private void tableClick() {
        int row = table.getSelectedRow();
        if (row != -1) {
            selectedId = (int) table.getValueAt(row, 0);
            txtKode.setText(table.getValueAt(row, 1).toString());
            txtNama.setText(table.getValueAt(row, 2).toString());
            
            // Set kategori
            String kategori = table.getValueAt(row, 3).toString();
            for (int i = 0; i < cmbKategori.getItemCount(); i++) {
                if (cmbKategori.getItemAt(i).equals(kategori)) {
                    cmbKategori.setSelectedIndex(i);
                    break;
                }
            }
            
            txtStok.setText(table.getValueAt(row, 4).toString());
            
            // Parse harga
            String hargaStr = table.getValueAt(row, 5).toString();
            hargaStr = hargaStr.replaceAll("[^0-9.]", "");
            txtHarga.setText(hargaStr);
            
            txtSatuan.setText(table.getValueAt(row, 6).toString());
            
            btnSave.setEnabled(false);
            btnUpdate.setEnabled(true);
            btnDelete.setEnabled(true);
        }
    }
}