package com.JaTrack.form;

import com.JaTrack.dao.LaporanDAO;
import com.JaTrack.model.Distributor;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Desktop;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormLaporanDistributor extends Form {
    
    private JTextField txtSearch;
    private JComboBox<String> cmbFilter;
    private JButton btnTampilkan, btnPrint, btnExport, btnRefresh;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblTotalDistributor, lblTotalTransaksi;
    
    private LaporanDAO laporanDAO;
    private Connection conn;
    
    public FormLaporanDistributor() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            laporanDAO = new LaporanDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]10[]"));
        
        JPanel panelHeader = createHeaderPanel();
        add(panelHeader, "wrap");
        
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow, wrap");
        
        JPanel panelSummary = createSummaryPanel();
        add(panelSummary, "grow");
        
        // Load data
        loadData();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]10[grow][]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Laporan Distributor");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +5");
        
        panel.add(lblTitle, "span, wrap 15");
        
        // Filter
        cmbFilter = new JComboBox<>(new String[]{
            "Semua Distributor",
            "Dengan Transaksi",
            "Tanpa Transaksi"
        });
        
        txtSearch = new JTextField();
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari nama distributor...");
        
        btnTampilkan = new JButton(" Cari");
        btnRefresh = new JButton(" Refresh");
        btnPrint = new JButton(" Print");
        btnExport = new JButton(" Export");
        
        btnTampilkan.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnRefresh.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        btnPrint.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnExport.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        
        panel.add(new JLabel("Filter:"));
        panel.add(cmbFilter, "w 200!");
        panel.add(txtSearch, "grow");
        panel.add(btnTampilkan);
        panel.add(btnRefresh, "wrap");
        
        panel.add(btnPrint, "skip 2");
        panel.add(btnExport);
        
        // Events
        btnTampilkan.addActionListener(e -> searchData());
        btnRefresh.addActionListener(e -> loadData());
        btnPrint.addActionListener(e -> printLaporan());
        btnExport.addActionListener(e -> exportToCSV());
        txtSearch.addActionListener(e -> searchData());
        cmbFilter.addActionListener(e -> filterData());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblData = new JLabel(" Data Distributor");
        lblData.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        panel.add(lblData, "wrap");
        
        String[] columns = {"No", "Nama Distributor", "Alamat", "No. Telepon", "Kontak Person", "Jenis Barang", "Total Transaksi"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(200);
        table.getColumnModel().getColumn(2).setPreferredWidth(250);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(150);
        table.getColumnModel().getColumn(6).setPreferredWidth(120);
        
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, "grow");
        
        return panel;
    }
    
    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow][grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:#E3F2FD");
        
        lblTotalDistributor = new JLabel(" Total Distributor: 0");
        lblTotalDistributor.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblTotalTransaksi = new JLabel(" Total Transaksi: 0");
        lblTotalTransaksi.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        panel.add(lblTotalDistributor, "grow");
        panel.add(lblTotalTransaksi, "grow");
        
        return panel;
    }
    
    private void loadData() {
        tableModel.setRowCount(0);
        
        try {
            List<Object[]> list = laporanDAO.getLaporanDistributorLengkap();
            int no = 1;
            int totalTransaksi = 0;
            
            for (Object[] row : list) {
                int idDistributor = (int) row[0];
                String nama = (String) row[1];
                String alamat = (String) row[2];
                String telepon = (String) row[3];
                String kontak = (String) row[4];
                String jenisBarang = (String) row[5];
                int jumlahTransaksi = (int) row[6];
                
                tableModel.addRow(new Object[]{
                    no++,
                    nama,
                    alamat,
                    telepon,
                    kontak,
                    jenisBarang,
                    jumlahTransaksi + " kali"
                });
                
                totalTransaksi += jumlahTransaksi;
            }
            
            // Update summary
            lblTotalDistributor.setText(" Total Distributor: " + list.size());
            lblTotalTransaksi.setText(" Total Transaksi: " + totalTransaksi);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void filterData() {
        int filterIndex = cmbFilter.getSelectedIndex();
        tableModel.setRowCount(0);
        
        try {
            List<Object[]> list = laporanDAO.getLaporanDistributorLengkap();
            int no = 1;
            int totalTransaksi = 0;
            
            for (Object[] row : list) {
                int jumlahTransaksi = (int) row[6];
                boolean tampilkan = false;
                
                if (filterIndex == 0) { // Semua
                    tampilkan = true;
                } else if (filterIndex == 1) { // Dengan transaksi
                    tampilkan = jumlahTransaksi > 0;
                } else if (filterIndex == 2) { // Tanpa transaksi
                    tampilkan = jumlahTransaksi == 0;
                }
                
                if (tampilkan) {
                    tableModel.addRow(new Object[]{
                        no++,
                        row[1], // nama
                        row[2], // alamat
                        row[3], // telepon
                        row[4], // kontak
                        row[5], // jenis barang
                        jumlahTransaksi + " kali"
                    });
                    
                    totalTransaksi += jumlahTransaksi;
                }
            }
            
            lblTotalDistributor.setText(" Total Distributor: " + (no - 1));
            lblTotalTransaksi.setText(" Total Transaksi: " + totalTransaksi);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void searchData() {
        String keyword = txtSearch.getText().trim().toLowerCase();
        
        if (keyword.isEmpty()) {
            loadData();
            return;
        }
        
        tableModel.setRowCount(0);
        
        try {
            List<Object[]> list = laporanDAO.getLaporanDistributorLengkap();
            int no = 1;
            int totalTransaksi = 0;
            
            for (Object[] row : list) {
                String nama = ((String) row[1]).toLowerCase();
                String jenisBarang = row[5] != null ? ((String) row[5]).toLowerCase() : "";
                
                if (nama.contains(keyword) || jenisBarang.contains(keyword)) {
                    int jumlahTransaksi = (int) row[6];
                    
                    tableModel.addRow(new Object[]{
                        no++,
                        row[1],
                        row[2],
                        row[3],
                        row[4],
                        row[5],
                        jumlahTransaksi + " kali"
                    });
                    
                    totalTransaksi += jumlahTransaksi;
                }
            }
            
            lblTotalDistributor.setText(" Total Distributor: " + (no - 1));
            lblTotalTransaksi.setText(" Total Transaksi: " + totalTransaksi);
            
            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void printLaporan() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-print!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            String tanggal = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
            
            MessageFormat header = new MessageFormat("LAPORAN DISTRIBUTOR\nDicetak: " + tanggal);
            MessageFormat footer = new MessageFormat("Halaman {0}");
            
            boolean complete = table.print(JTable.PrintMode.FIT_WIDTH, header, footer, true, null, true, null);
            
            if (complete) {
                JOptionPane.showMessageDialog(this, " Print berhasil!");
            }
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-export!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new File("Laporan_Distributor_" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".csv"));
        
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try (FileOutputStream fos = new FileOutputStream(file)) {
                StringBuilder sb = new StringBuilder();
                sb.append("LAPORAN DISTRIBUTOR\n");
                sb.append("Tanggal: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date())).append("\n\n");
                
                // Headers
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    sb.append(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) sb.append(",");
                }
                sb.append("\n");
                
                // Data
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object val = tableModel.getValueAt(row, col);
                        sb.append(val != null ? val.toString().replace(",", ";") : "");
                        if (col < tableModel.getColumnCount() - 1) sb.append(",");
                    }
                    sb.append("\n");
                }
                
                sb.append("\n").append(lblTotalDistributor.getText()).append("\n");
                sb.append(lblTotalTransaksi.getText()).append("\n");
                
                fos.write(sb.toString().getBytes());
                
                JOptionPane.showMessageDialog(this, " File berhasil disimpan!");
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(file);
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }
}