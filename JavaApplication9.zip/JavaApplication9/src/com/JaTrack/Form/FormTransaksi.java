package com.JaTrack.form;

import com.JaTrack.dao.TransaksiDAO;
import com.JaTrack.dao.BarangDAO;
import com.JaTrack.dao.ProduksiDAO;
import com.JaTrack.dao.DistributorDAO;
import com.JaTrack.model.BarangMasuk;
import com.JaTrack.model.BarangKeluar;
import com.JaTrack.model.Barang;
import com.JaTrack.model.Produksi;
import com.JaTrack.model.Distributor;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormTransaksi extends Form {
    
    // Components
    private JTabbedPane tabbedPane;
    
    // Tab Barang Masuk
    private JDateChooser dateMasuk;
    private JTextField txtJumlahMasuk, txtKeteranganMasuk, txtSearchMasuk;
    private JComboBox<String> cmbBarangMasuk, cmbSupplier;
    private JButton btnSaveMasuk, btnDeleteMasuk, btnClearMasuk, btnSearchMasuk;
    private JTable tableMasuk;
    private DefaultTableModel modelMasuk;
    
    // Tab Barang Keluar
    private JDateChooser dateKeluar;
    private JTextField txtNamaBarangKeluar, txtJumlahKeluar, txtSatuanKeluar, 
                       txtCustomer, txtKeteranganKeluar, txtSearchKeluar;
    private JComboBox<String> cmbProduksi;
    private JButton btnSaveKeluar, btnDeleteKeluar, btnClearKeluar, btnSearchKeluar;
    private JTable tableKeluar;
    private DefaultTableModel modelKeluar;
    
    private TransaksiDAO transaksiDAO;
    private BarangDAO barangDAO;
    private ProduksiDAO produksiDAO;
    private DistributorDAO distributorDAO;
    private Connection conn;
    
    private List<Barang> listBarang;
    private List<Produksi> listProduksi;
    private List<Distributor> listDistributor;
    
    public FormTransaksi() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            transaksiDAO = new TransaksiDAO(conn);
            barangDAO = new BarangDAO(conn);
            produksiDAO = new ProduksiDAO(conn);
            distributorDAO = new DistributorDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 10", "[grow]", "[grow]"));
        
        tabbedPane = new JTabbedPane();
        tabbedPane.putClientProperty(FlatClientProperties.STYLE, "tabHeight:40");
        
        // Tab 1: Barang Masuk
        JPanel panelMasuk = createPanelBarangMasuk();
        tabbedPane.addTab(" BARANG MASUK", panelMasuk);
        
        // Tab 2: Barang Keluar
        JPanel panelKeluar = createPanelBarangKeluar();
        tabbedPane.addTab(" BARANG KELUAR", panelKeluar);
        
        add(tabbedPane, "grow");
        
        // Load data
        loadBarangToComboBox();
        loadDistributorToComboBox();
        loadProduksiToComboBox();
        loadDataBarangMasuk();
        loadDataBarangKeluar();
    }
    
    /**
     * ========================================
     * PANEL BARANG MASUK
     * ========================================
     */
    private JPanel createPanelBarangMasuk() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[50%][50%]", "[]10[grow]"));
        
        // Panel Kiri - Form Input
        JPanel panelForm = new JPanel(new MigLayout("fill, insets 15", "[grow]", ""));
        panelForm.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Form Barang Masuk");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        
        dateMasuk = new JDateChooser();
        dateMasuk.setDate(new Date());
        cmbBarangMasuk = new JComboBox<>();
        cmbSupplier = new JComboBox<>();
        txtJumlahMasuk = new JTextField();
        txtKeteranganMasuk = new JTextField();
        
        txtJumlahMasuk.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Jumlah yang diterima");
        txtKeteranganMasuk.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Keterangan (optional)");
        
        btnSaveMasuk = new JButton(" Simpan");
        btnClearMasuk = new JButton(" Batal");
        
        btnSaveMasuk.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnClearMasuk.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        panelForm.add(lblTitle, "wrap 15");
        panelForm.add(new JLabel("Tanggal Terima:"), "wrap");
        panelForm.add(dateMasuk, "grow, wrap 10");
        panelForm.add(new JLabel("Pilih Barang:"), "wrap");
        panelForm.add(cmbBarangMasuk, "grow, wrap 10");
        panelForm.add(new JLabel("Jumlah:"), "wrap");
        panelForm.add(txtJumlahMasuk, "grow, wrap 10");
        panelForm.add(new JLabel("Supplier/Distributor:"), "wrap");
        panelForm.add(cmbSupplier, "grow, wrap 10");
        panelForm.add(new JLabel("Keterangan:"), "wrap");
        panelForm.add(txtKeteranganMasuk, "grow, wrap 20");
        panelForm.add(btnSaveMasuk, "split 2, grow");
        panelForm.add(btnClearMasuk, "grow");
        
        panel.add(panelForm, "grow");
        
        // Panel Kanan - Tabel History
        JPanel panelTable = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panelTable.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblHistory = new JLabel(" History Barang Masuk");
        lblHistory.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        
        txtSearchMasuk = new JTextField();
        btnSearchMasuk = new JButton("src");
        btnDeleteMasuk = new JButton(" Hapus");
        
        txtSearchMasuk.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari barang atau supplier...");
        btnSearchMasuk.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        btnDeleteMasuk.putClientProperty(FlatClientProperties.STYLE, "background:#F44336");
        
        panelTable.add(lblHistory, "wrap 10");
        panelTable.add(txtSearchMasuk, "split 3, grow");
        panelTable.add(btnSearchMasuk);
        panelTable.add(btnDeleteMasuk, "wrap 10");
        
        String[] colsMasuk = {"ID", "Tanggal", "Nama Barang", "Jumlah", "Satuan", "Supplier", "Keterangan"};
        modelMasuk = new DefaultTableModel(colsMasuk, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tableMasuk = new JTable(modelMasuk);
        tableMasuk.getColumnModel().getColumn(0).setMaxWidth(50);
        tableMasuk.setRowHeight(30);
        JScrollPane scrollMasuk = new JScrollPane(tableMasuk);
        
        panelTable.add(scrollMasuk, "grow");
        panel.add(panelTable, "grow");
        
        // Event Listeners
        btnSaveMasuk.addActionListener(e -> saveBarangMasuk());
        btnClearMasuk.addActionListener(e -> clearFormMasuk());
        btnSearchMasuk.addActionListener(e -> searchBarangMasuk());
        btnDeleteMasuk.addActionListener(e -> deleteBarangMasuk());
        txtSearchMasuk.addActionListener(e -> searchBarangMasuk());
        
        return panel;
    }
    
    /**
     * ========================================
     * PANEL BARANG KELUAR
     * ========================================
     */
    private JPanel createPanelBarangKeluar() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[50%][50%]", "[]10[grow]"));
        
        // Panel Kiri - Form Input
        JPanel panelForm = new JPanel(new MigLayout("fill, insets 15", "[grow]", ""));
        panelForm.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Form Barang Keluar");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        
        dateKeluar = new JDateChooser();
        dateKeluar.setDate(new Date());
        cmbProduksi = new JComboBox<>();
        txtNamaBarangKeluar = new JTextField();
        txtJumlahKeluar = new JTextField();
        txtSatuanKeluar = new JTextField();
        txtCustomer = new JTextField();
        txtKeteranganKeluar = new JTextField();
        
        txtNamaBarangKeluar.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Nama barang jadi");
        txtJumlahKeluar.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Jumlah yang dikirim");
        txtSatuanKeluar.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "pcs, unit, dll");
        txtCustomer.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Nama customer/pelanggan");
        txtKeteranganKeluar.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Keterangan (optional)");
        
        btnSaveKeluar = new JButton(" Simpan");
        btnClearKeluar = new JButton(" Batal");
        
        btnSaveKeluar.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnClearKeluar.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        panelForm.add(lblTitle, "wrap 15");
        panelForm.add(new JLabel("Tanggal Keluar:"), "wrap");
        panelForm.add(dateKeluar, "grow, wrap 10");
        panelForm.add(new JLabel("Referensi Produksi (Optional):"), "wrap");
        panelForm.add(cmbProduksi, "grow, wrap 10");
        panelForm.add(new JLabel("Nama Barang:"), "wrap");
        panelForm.add(txtNamaBarangKeluar, "grow, wrap 10");
        panelForm.add(new JLabel("Jumlah:"), "wrap");
        panelForm.add(txtJumlahKeluar, "grow, wrap 10");
        panelForm.add(new JLabel("Satuan:"), "wrap");
        panelForm.add(txtSatuanKeluar, "grow, wrap 10");
        panelForm.add(new JLabel("Customer:"), "wrap");
        panelForm.add(txtCustomer, "grow, wrap 10");
        panelForm.add(new JLabel("Keterangan:"), "wrap");
        panelForm.add(txtKeteranganKeluar, "grow, wrap 20");
        panelForm.add(btnSaveKeluar, "split 2, grow");
        panelForm.add(btnClearKeluar, "grow");
        
        panel.add(panelForm, "grow");
        
        // Panel Kanan - Tabel History
        JPanel panelTable = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panelTable.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblHistory = new JLabel(" History Barang Keluar");
        lblHistory.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        
        txtSearchKeluar = new JTextField();
        btnSearchKeluar = new JButton("src");
        btnDeleteKeluar = new JButton(" Hapus");
        
        txtSearchKeluar.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari barang atau customer...");
        btnSearchKeluar.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        btnDeleteKeluar.putClientProperty(FlatClientProperties.STYLE, "background:#F44336");
        
        panelTable.add(lblHistory, "wrap 10");
        panelTable.add(txtSearchKeluar, "split 3, grow");
        panelTable.add(btnSearchKeluar);
        panelTable.add(btnDeleteKeluar, "wrap 10");
        
        String[] colsKeluar = {"ID", "Tanggal", "Nama Barang", "Jumlah", "Satuan", "Customer", "Keterangan"};
        modelKeluar = new DefaultTableModel(colsKeluar, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        tableKeluar = new JTable(modelKeluar);
        tableKeluar.getColumnModel().getColumn(0).setMaxWidth(50);
        tableKeluar.setRowHeight(30);
        JScrollPane scrollKeluar = new JScrollPane(tableKeluar);
        
        panelTable.add(scrollKeluar, "grow");
        panel.add(panelTable, "grow");
        
        // Event Listeners
        btnSaveKeluar.addActionListener(e -> saveBarangKeluar());
        btnClearKeluar.addActionListener(e -> clearFormKeluar());
        btnSearchKeluar.addActionListener(e -> searchBarangKeluar());
        btnDeleteKeluar.addActionListener(e -> deleteBarangKeluar());
        txtSearchKeluar.addActionListener(e -> searchBarangKeluar());
        
        return panel;
    }
    
    /**
     * ========================================
     * BARANG MASUK METHODS
     * ========================================
     */
    
    private void loadBarangToComboBox() {
        try {
            listBarang = barangDAO.getAll();
            cmbBarangMasuk.removeAllItems();
            cmbBarangMasuk.addItem("-- Pilih Barang --");
            
            for (Barang b : listBarang) {
                cmbBarangMasuk.addItem(b.getNamaBarang() + " (Stok: " + b.getStok() + ")");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading barang: " + e.getMessage());
        }
    }
    
    private void loadDistributorToComboBox() {
        try {
            listDistributor = distributorDAO.getAll();
            cmbSupplier.removeAllItems();
            cmbSupplier.addItem("-- Pilih Supplier --");
            
            for (Distributor d : listDistributor) {
                cmbSupplier.addItem(d.getNamaDistributor());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading distributor: " + e.getMessage());
        }
    }
    
    private void saveBarangMasuk() {
        int selectedIndexBarang = cmbBarangMasuk.getSelectedIndex();
        int selectedIndexSupplier = cmbSupplier.getSelectedIndex();
        
        if (selectedIndexBarang <= 0) {
            JOptionPane.showMessageDialog(this, "Pilih barang terlebih dahulu!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (selectedIndexSupplier <= 0) {
            JOptionPane.showMessageDialog(this, "Pilih supplier terlebih dahulu!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        String jumlahStr = txtJumlahMasuk.getText().trim();
        if (jumlahStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Jumlah harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int jumlah = Integer.parseInt(jumlahStr);
            Barang barang = listBarang.get(selectedIndexBarang - 1);
            Distributor distributor = listDistributor.get(selectedIndexSupplier - 1);
            
            BarangMasuk bm = new BarangMasuk();
            bm.setTanggalMasuk(dateMasuk.getDate());
            bm.setIdBarang(barang.getIdBarang());
            bm.setNamaBarang(barang.getNamaBarang());
            bm.setJumlah(jumlah);
            bm.setSatuan(barang.getSatuan());
            bm.setSupplier(distributor.getNamaDistributor());
            bm.setKeterangan(txtKeteranganMasuk.getText().trim());
            
            if (transaksiDAO.insertBarangMasuk(bm)) {
                JOptionPane.showMessageDialog(this, " Barang masuk berhasil!\n🔄 Stok otomatis bertambah!");
                clearFormMasuk();
                loadDataBarangMasuk();
                loadBarangToComboBox(); // Refresh stok
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menyimpan!");
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadDataBarangMasuk() {
        modelMasuk.setRowCount(0);
        
        try {
            List<BarangMasuk> list = transaksiDAO.getAllBarangMasuk();
            for (BarangMasuk bm : list) {
                modelMasuk.addRow(new Object[]{
                    bm.getIdMasuk(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(bm.getTanggalMasuk()),
                    bm.getNamaBarang(),
                    bm.getJumlah(),
                    bm.getSatuan(),
                    bm.getSupplier(),
                    bm.getKeterangan()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void deleteBarangMasuk() {
        int row = tableMasuk.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int idMasuk = (int) tableMasuk.getValueAt(row, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Hapus transaksi ini? Stok akan dikembalikan!", 
            "Konfirmasi", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (transaksiDAO.deleteBarangMasuk(idMasuk)) {
                JOptionPane.showMessageDialog(this, " Data berhasil dihapus!");
                loadDataBarangMasuk();
                loadBarangToComboBox();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menghapus!");
            }
        }
    }
    
    private void searchBarangMasuk() {
        String keyword = txtSearchMasuk.getText().trim();
        
        if (keyword.isEmpty()) {
            loadDataBarangMasuk();
            return;
        }
        
        modelMasuk.setRowCount(0);
        try {
            List<BarangMasuk> list = transaksiDAO.searchBarangMasuk(keyword);
            for (BarangMasuk bm : list) {
                modelMasuk.addRow(new Object[]{
                    bm.getIdMasuk(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(bm.getTanggalMasuk()),
                    bm.getNamaBarang(),
                    bm.getJumlah(),
                    bm.getSatuan(),
                    bm.getSupplier(),
                    bm.getKeterangan()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void clearFormMasuk() {
        dateMasuk.setDate(new Date());
        cmbBarangMasuk.setSelectedIndex(0);
        cmbSupplier.setSelectedIndex(0);
        txtJumlahMasuk.setText("");
        txtKeteranganMasuk.setText("");
        tableMasuk.clearSelection();
    }
    
    /**
     * ========================================
     * BARANG KELUAR METHODS
     * ========================================
     */
    
    private void loadProduksiToComboBox() {
        try {
            listProduksi = produksiDAO.getAll();
            cmbProduksi.removeAllItems();
            cmbProduksi.addItem("-- Tanpa Referensi --");
            
            for (Produksi p : listProduksi) {
                cmbProduksi.addItem("#" + p.getIdProduksi() + " - " + p.getHasilProduksi());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading produksi: " + e.getMessage());
        }
    }
    
    private void saveBarangKeluar() {
        if (txtNamaBarangKeluar.getText().trim().isEmpty() || 
            txtJumlahKeluar.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nama barang dan jumlah harus diisi!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            int jumlah = Integer.parseInt(txtJumlahKeluar.getText().trim());
            int idProduksi = 0;
            
            if (cmbProduksi.getSelectedIndex() > 0) {
                idProduksi = listProduksi.get(cmbProduksi.getSelectedIndex() - 1).getIdProduksi();
            }
            
            BarangKeluar bk = new BarangKeluar();
            bk.setTanggalKeluar(dateKeluar.getDate());
            bk.setIdProduksi(idProduksi);
            bk.setNamaBarang(txtNamaBarangKeluar.getText().trim());
            bk.setJumlah(jumlah);
            bk.setSatuan(txtSatuanKeluar.getText().trim());
            bk.setCustomer(txtCustomer.getText().trim());
            bk.setKeterangan(txtKeteranganKeluar.getText().trim());
            
            if (transaksiDAO.insertBarangKeluar(bk)) {
                JOptionPane.showMessageDialog(this, " Barang keluar berhasil dicatat!");
                clearFormKeluar();
                loadDataBarangKeluar();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menyimpan!");
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Jumlah harus berupa angka!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void loadDataBarangKeluar() {
        modelKeluar.setRowCount(0);
        
        try {
            List<BarangKeluar> list = transaksiDAO.getAllBarangKeluar();
            for (BarangKeluar bk : list) {
                modelKeluar.addRow(new Object[]{
                    bk.getIdKeluar(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(bk.getTanggalKeluar()),
                    bk.getNamaBarang(),
                    bk.getJumlah(),
                    bk.getSatuan(),
                    bk.getCustomer(),
                    bk.getKeterangan()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void deleteBarangKeluar() {
        int row = tableKeluar.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang akan dihapus!", "Peringatan", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int idKeluar = (int) tableKeluar.getValueAt(row, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Hapus transaksi ini?", 
            "Konfirmasi", 
            JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (transaksiDAO.deleteBarangKeluar(idKeluar)) {
                JOptionPane.showMessageDialog(this, " Data berhasil dihapus!");
                loadDataBarangKeluar();
            } else {
                JOptionPane.showMessageDialog(this, " Gagal menghapus!");
            }
        }
    }
    
    private void searchBarangKeluar() {
        String keyword = txtSearchKeluar.getText().trim();
        
        if (keyword.isEmpty()) {
            loadDataBarangKeluar();
            return;
        }
        
        modelKeluar.setRowCount(0);
        try {
            List<BarangKeluar> list = transaksiDAO.searchBarangKeluar(keyword);
            for (BarangKeluar bk : list) {
                modelKeluar.addRow(new Object[]{
                    bk.getIdKeluar(),
                    new java.text.SimpleDateFormat("dd-MM-yyyy").format(bk.getTanggalKeluar()),
                    bk.getNamaBarang(),
                    bk.getJumlah(),
                    bk.getSatuan(),
                    bk.getCustomer(),
                    bk.getKeterangan()
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void clearFormKeluar() {
        dateKeluar.setDate(new Date());
        cmbProduksi.setSelectedIndex(0);
        txtNamaBarangKeluar.setText("");
        txtJumlahKeluar.setText("");
        txtSatuanKeluar.setText("");
        txtCustomer.setText("");
        txtKeteranganKeluar.setText("");
        tableKeluar.clearSelection();
    }
}