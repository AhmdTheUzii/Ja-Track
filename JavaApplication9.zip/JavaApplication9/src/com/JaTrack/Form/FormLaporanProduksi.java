package com.JaTrack.form;

import com.JaTrack.dao.LaporanDAO;
import com.JaTrack.model.Produksi;
import com.JaTrack.model.DetailProduksi;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import com.toedter.calendar.JDateChooser;
import java.awt.Desktop;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormLaporanProduksi extends Form {
    
    private JDateChooser dateDari, dateSampai;
    private JButton btnTampilkan, btnPrint, btnExport, btnDetail, btnReset;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblTotalProduksi, lblTotalBahan;
    
    private LaporanDAO laporanDAO;
    private Connection conn;
    
    public FormLaporanProduksi() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            laporanDAO = new LaporanDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]10[]"));
        
        JPanel panelHeader = createHeaderPanel();
        add(panelHeader, "wrap");
        
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow, wrap");
        
        JPanel panelSummary = createSummaryPanel();
        add(panelSummary, "grow");
        
        // Load data default
        loadData();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]10[]10[]10[grow][]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Laporan Produksi");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +5");
        
        panel.add(lblTitle, "span, wrap 15");
        
        // Filter
        dateDari = new JDateChooser();
        dateSampai = new JDateChooser();
        
        // Default 30 hari
        Date now = new Date();
        dateSampai.setDate(now);
        dateDari.setDate(new Date(now.getTime() - (30L * 24 * 60 * 60 * 1000)));
        
        btnTampilkan = new JButton(" Tampilkan");
        btnReset = new JButton(" Reset");
        btnDetail = new JButton(" Lihat Detail");
        btnPrint = new JButton(" Print");
        btnExport = new JButton(" Export");
        
        btnTampilkan.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnReset.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        btnDetail.putClientProperty(FlatClientProperties.STYLE, "background:#9C27B0");
        btnPrint.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnExport.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        
        panel.add(new JLabel("Dari:"));
        panel.add(dateDari, "w 150!");
        panel.add(new JLabel("Sampai:"));
        panel.add(dateSampai, "w 150!");
        panel.add(btnTampilkan);
        panel.add(btnReset, "wrap");
        
        panel.add(btnDetail, "skip 4");
        panel.add(btnPrint);
        panel.add(btnExport);
        
        // Events
        btnTampilkan.addActionListener(e -> loadData());
        btnReset.addActionListener(e -> resetFilter());
        btnDetail.addActionListener(e -> showDetailBahan());
        btnPrint.addActionListener(e -> printLaporan());
        btnExport.addActionListener(e -> exportToCSV());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblData = new JLabel(" Data Produksi");
        lblData.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        panel.add(lblData, "wrap");
        
        String[] columns = {"No", "ID", "Tanggal", "Hasil Produksi", "Jumlah Bahan", "Keterangan"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setMaxWidth(70);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(250);
        table.getColumnModel().getColumn(4).setPreferredWidth(120);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
        
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, "grow");
        
        return panel;
    }
    
    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow][grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:#E3F2FD");
        
        lblTotalProduksi = new JLabel(" Total Produksi: 0");
        lblTotalProduksi.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblTotalBahan = new JLabel(" Total Bahan Digunakan: 0");
        lblTotalBahan.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        panel.add(lblTotalProduksi, "grow");
        panel.add(lblTotalBahan, "grow");
        
        return panel;
    }
    
    private void loadData() {
        if (dateDari.getDate() == null || dateSampai.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Pilih tanggal terlebih dahulu!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        tableModel.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        
        try {
            List<Object[]> list = laporanDAO.getLaporanProduksiLengkap(dateDari.getDate(), dateSampai.getDate());
            int no = 1;
            int totalBahan = 0;
            
            for (Object[] row : list) {
                int idProduksi = (int) row[0];
                Date tanggal = (Date) row[1];
                String hasil = (String) row[2];
                int jumlahBahan = (int) row[3];
                String keterangan = (String) row[4];
                
                tableModel.addRow(new Object[]{
                    no++,
                    idProduksi,
                    sdf.format(tanggal),
                    hasil,
                    jumlahBahan + " jenis",
                    keterangan
                });
                
                totalBahan += jumlahBahan;
            }
            
            // Update summary
            lblTotalProduksi.setText(" Total Produksi: " + list.size());
            lblTotalBahan.setText(" Total Bahan Digunakan: " + totalBahan + " jenis");
            
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Tidak ada data pada periode tersebut!", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void showDetailBahan() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Pilih produksi yang ingin dilihat detailnya!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int idProduksi = (int) table.getValueAt(row, 1);
        String hasilProduksi = table.getValueAt(row, 3).toString();
        
        try {
            List<DetailProduksi> details = laporanDAO.getDetailProduksi(idProduksi);
            
            if (details.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Tidak ada detail bahan untuk produksi ini!", "Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            // Bikin tabel detail
            String[] cols = {"No", "Nama Barang", "Jumlah", "Satuan"};
            DefaultTableModel detailModel = new DefaultTableModel(cols, 0);
            
            int no = 1;
            for (DetailProduksi d : details) {
                detailModel.addRow(new Object[]{
                    no++,
                    d.getNamaBarang(),
                    d.getJumlahDigunakan(),
                    d.getSatuan()
                });
            }
            
            JTable detailTable = new JTable(detailModel);
            detailTable.setRowHeight(25);
            JScrollPane scroll = new JScrollPane(detailTable);
            scroll.setPreferredSize(new java.awt.Dimension(500, 300));
            
            JOptionPane.showMessageDialog(this, scroll, 
                "Detail Bahan - " + hasilProduksi, 
                JOptionPane.PLAIN_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void resetFilter() {
        Date now = new Date();
        dateSampai.setDate(now);
        dateDari.setDate(new Date(now.getTime() - (30L * 24 * 60 * 60 * 1000)));
        loadData();
    }
    
    private void printLaporan() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-print!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String periode = sdf.format(dateDari.getDate()) + " - " + sdf.format(dateSampai.getDate());
            
            MessageFormat header = new MessageFormat("LAPORAN PRODUKSI\nPeriode: " + periode);
            MessageFormat footer = new MessageFormat("Halaman {0}");
            
            boolean complete = table.print(JTable.PrintMode.FIT_WIDTH, header, footer, true, null, true, null);
            
            if (complete) {
                JOptionPane.showMessageDialog(this, " Print berhasil!");
            }
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-export!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new File("Laporan_Produksi_" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".csv"));
        
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try (FileOutputStream fos = new FileOutputStream(file)) {
                StringBuilder sb = new StringBuilder();
                sb.append("LAPORAN PRODUKSI\n");
                sb.append("Periode: ").append(new SimpleDateFormat("dd/MM/yyyy").format(dateDari.getDate()))
                  .append(" - ").append(new SimpleDateFormat("dd/MM/yyyy").format(dateSampai.getDate())).append("\n\n");
                
                // Headers
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    sb.append(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) sb.append(",");
                }
                sb.append("\n");
                
                // Data
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object val = tableModel.getValueAt(row, col);
                        sb.append(val != null ? val.toString().replace(",", ";") : "");
                        if (col < tableModel.getColumnCount() - 1) sb.append(",");
                    }
                    sb.append("\n");
                }
                
                sb.append("\n").append(lblTotalProduksi.getText()).append("\n");
                sb.append(lblTotalBahan.getText()).append("\n");
                
                fos.write(sb.toString().getBytes());
                
                JOptionPane.showMessageDialog(this, " File berhasil disimpan!");
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(file);
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }
}