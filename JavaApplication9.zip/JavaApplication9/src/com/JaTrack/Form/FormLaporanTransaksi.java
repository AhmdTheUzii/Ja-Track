package com.JaTrack.form;

import com.JaTrack.dao.TransaksiDAO;
import com.JaTrack.model.BarangMasuk;
import com.JaTrack.model.BarangKeluar;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import com.toedter.calendar.JDateChooser;
import java.awt.Desktop;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormLaporanTransaksi extends Form {
    
    private JDateChooser dateDari, dateSampai;
    private JComboBox<String> cmbJenis;
    private JButton btnTampilkan, btnPrint, btnExport, btnReset;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblTotalTransaksi, lblTotalMasuk, lblTotalKeluar;
    
    private TransaksiDAO transaksiDAO;
    private Connection conn;
    
    public FormLaporanTransaksi() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            transaksiDAO = new TransaksiDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]10[]"));
        
        JPanel panelHeader = createHeaderPanel();
        add(panelHeader, "wrap");
        
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow, wrap");
        
        JPanel panelSummary = createSummaryPanel();
        add(panelSummary, "grow");
        
        // Load data default (30 hari terakhir)
        loadData();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]10[]10[]10[]10[grow][]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Laporan Transaksi");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +5");
        
        panel.add(lblTitle, "span, wrap 15");
        
        // Filter
        dateDari = new JDateChooser();
        dateSampai = new JDateChooser();
        cmbJenis = new JComboBox<>(new String[]{
            "Semua Transaksi",
            "Barang Masuk",
            "Barang Keluar"
        });
        
        // Set default (30 hari terakhir)
        Date now = new Date();
        dateSampai.setDate(now);
        dateDari.setDate(new Date(now.getTime() - (30L * 24 * 60 * 60 * 1000)));
        
        btnTampilkan = new JButton(" Tampilkan");
        btnReset = new JButton(" Reset");
        btnPrint = new JButton(" Print");
        btnExport = new JButton(" Export");
        
        btnTampilkan.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnReset.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        btnPrint.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnExport.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        
        panel.add(new JLabel("Dari:"));
        panel.add(dateDari, "w 150!");
        panel.add(new JLabel("Sampai:"));
        panel.add(dateSampai, "w 150!");
        panel.add(new JLabel("Jenis:"));
        panel.add(cmbJenis, "w 180!");
        panel.add(btnTampilkan);
        panel.add(btnReset, "wrap");
        
        panel.add(btnPrint, "skip 6");
        panel.add(btnExport);
        
        // Events
        btnTampilkan.addActionListener(e -> loadData());
        btnReset.addActionListener(e -> resetFilter());
        btnPrint.addActionListener(e -> printLaporan());
        btnExport.addActionListener(e -> exportToCSV());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblData = new JLabel(" Data Transaksi");
        lblData.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        panel.add(lblData, "wrap");
        
        String[] columns = {"No", "Tanggal", "Jenis", "Nama Barang", "Jumlah", "Satuan", "Supplier/Customer", "Keterangan"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, "grow");
        
        return panel;
    }
    
    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow][grow][grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:#E3F2FD");
        
        lblTotalTransaksi = new JLabel(" Total Transaksi: 0");
        lblTotalTransaksi.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblTotalMasuk = new JLabel(" Barang Masuk: 0");
        lblTotalMasuk.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblTotalKeluar = new JLabel(" Barang Keluar: 0");
        lblTotalKeluar.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        panel.add(lblTotalTransaksi, "grow");
        panel.add(lblTotalMasuk, "grow");
        panel.add(lblTotalKeluar, "grow");
        
        return panel;
    }
    
    private void loadData() {
        if (dateDari.getDate() == null || dateSampai.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Pilih tanggal terlebih dahulu!", "Validasi", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        tableModel.setRowCount(0);
        int jenisIndex = cmbJenis.getSelectedIndex();
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        
        int no = 1;
        int countMasuk = 0;
        int countKeluar = 0;
        
        try {
            // Barang Masuk
            if (jenisIndex == 0 || jenisIndex == 1) {
                List<BarangMasuk> listMasuk = getBarangMasukByDate(dateDari.getDate(), dateSampai.getDate());
                
                for (BarangMasuk bm : listMasuk) {
                    tableModel.addRow(new Object[]{
                        no++,
                        sdf.format(bm.getTanggalMasuk()),
                        "📥 MASUK",
                        bm.getNamaBarang(),
                        bm.getJumlah(),
                        bm.getSatuan(),
                        bm.getSupplier(),
                        bm.getKeterangan()
                    });
                    countMasuk++;
                }
            }
            
            // Barang Keluar
            if (jenisIndex == 0 || jenisIndex == 2) {
                List<BarangKeluar> listKeluar = getBarangKeluarByDate(dateDari.getDate(), dateSampai.getDate());
                
                for (BarangKeluar bk : listKeluar) {
                    tableModel.addRow(new Object[]{
                        no++,
                        sdf.format(bk.getTanggalKeluar()),
                        "📤 KELUAR",
                        bk.getNamaBarang(),
                        bk.getJumlah(),
                        bk.getSatuan(),
                        bk.getCustomer(),
                        bk.getKeterangan()
                    });
                    countKeluar++;
                }
            }
            
            // Update summary
            lblTotalTransaksi.setText(" Total Transaksi: " + (countMasuk + countKeluar));
            lblTotalMasuk.setText(" Barang Masuk: " + countMasuk);
            lblTotalKeluar.setText(" Barang Keluar: " + countKeluar);
            
            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Tidak ada data pada periode tersebut!", "Info", JOptionPane.INFORMATION_MESSAGE);
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private List<BarangMasuk> getBarangMasukByDate(Date dari, Date sampai) {
        List<BarangMasuk> list = new java.util.ArrayList<>();
        String sql = "SELECT * FROM barang_masuk WHERE tanggal_masuk BETWEEN ? AND ? ORDER BY tanggal_masuk DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangMasuk bm = new BarangMasuk();
                bm.setIdMasuk(rs.getInt("id_masuk"));
                bm.setTanggalMasuk(rs.getDate("tanggal_masuk"));
                bm.setIdBarang(rs.getInt("id_barang"));
                bm.setNamaBarang(rs.getString("nama_barang"));
                bm.setJumlah(rs.getInt("jumlah"));
                bm.setSatuan(rs.getString("satuan"));
                bm.setSupplier(rs.getString("supplier"));
                bm.setKeterangan(rs.getString("keterangan"));
                list.add(bm);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    private List<BarangKeluar> getBarangKeluarByDate(Date dari, Date sampai) {
        List<BarangKeluar> list = new java.util.ArrayList<>();
        String sql = "SELECT * FROM barang_keluar WHERE tanggal_keluar BETWEEN ? AND ? ORDER BY tanggal_keluar DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangKeluar bk = new BarangKeluar();
                bk.setIdKeluar(rs.getInt("id_keluar"));
                bk.setTanggalKeluar(rs.getDate("tanggal_keluar"));
                bk.setIdProduksi(rs.getInt("id_produksi"));
                bk.setNamaBarang(rs.getString("nama_barang"));
                bk.setJumlah(rs.getInt("jumlah"));
                bk.setSatuan(rs.getString("satuan"));
                bk.setCustomer(rs.getString("customer"));
                bk.setKeterangan(rs.getString("keterangan"));
                list.add(bk);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
    
    private void resetFilter() {
        Date now = new Date();
        dateSampai.setDate(now);
        dateDari.setDate(new Date(now.getTime() - (30L * 24 * 60 * 60 * 1000)));
        cmbJenis.setSelectedIndex(0);
        loadData();
    }
    
    private void printLaporan() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-print!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            String periode = sdf.format(dateDari.getDate()) + " - " + sdf.format(dateSampai.getDate());
            
            MessageFormat header = new MessageFormat("LAPORAN TRANSAKSI\nPeriode: " + periode);
            MessageFormat footer = new MessageFormat("Halaman {0}");
            
            boolean complete = table.print(JTable.PrintMode.FIT_WIDTH, header, footer, true, null, true, null);
            
            if (complete) {
                JOptionPane.showMessageDialog(this, " Print berhasil!");
            }
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-export!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setSelectedFile(new File("Laporan_Transaksi_" + new SimpleDateFormat("yyyyMMdd").format(new Date()) + ".csv"));
        
        if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try (FileOutputStream fos = new FileOutputStream(file)) {
                StringBuilder sb = new StringBuilder();
                sb.append("LAPORAN TRANSAKSI\n");
                sb.append("Periode: ").append(new SimpleDateFormat("dd/MM/yyyy").format(dateDari.getDate()))
                  .append(" - ").append(new SimpleDateFormat("dd/MM/yyyy").format(dateSampai.getDate())).append("\n\n");
                
                // Headers
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    sb.append(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) sb.append(",");
                }
                sb.append("\n");
                
                // Data
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object val = tableModel.getValueAt(row, col);
                        sb.append(val != null ? val.toString().replace(",", ";") : "");
                        if (col < tableModel.getColumnCount() - 1) sb.append(",");
                    }
                    sb.append("\n");
                }
                
                sb.append("\n").append(lblTotalTransaksi.getText()).append("\n");
                sb.append(lblTotalMasuk.getText()).append("\n");
                sb.append(lblTotalKeluar.getText()).append("\n");
                
                fos.write(sb.toString().getBytes());
                
                JOptionPane.showMessageDialog(this, " File berhasil disimpan!");
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(file);
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
            }
        }
    }
}