package com.JaTrack.form;

import com.JaTrack.dao.KategoriDAO;
import com.JaTrack.model.Kategori;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import java.sql.Connection;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;


public class FormKategori extends Form {
    
    // ========================================
    // DEKLARASI KOMPONEN UI
    // ========================================
    private JTextField txtKode, txtNama, txtSearch;
    private JTextArea txtDeskripsi;
    private JButton btnSave, btnUpdate, btnDelete, btnClear, btnSearch;
    private JTable table;
    private DefaultTableModel tableModel;
    
    // Database components
    private KategoriDAO dao;
    private Connection conn;
    private int selectedId = 0; // ID data yang dipilih di table
    
    // ========================================
    // CONSTRUCTOR
    // ========================================
    public FormKategori() {
        this.conn = com.JaTrack.util.DatabaseConnection.getInstance().getConnection();
       this.dao = new KategoriDAO(conn);
       init();
       loadData();
    }
    
    // Constructor dengan connection (DI - Dependency Injection)
    public FormKategori(Connection conn) {
        this.conn = conn;
        this.dao = new KategoriDAO(conn);
        init();
        loadData(); // Load data dari database
    }
    
    // ========================================
    // INIT - Setup layout utama
    // ========================================
    private void init() {
        setLayout(new MigLayout("fill, insets 20", "[grow]", "[]20[grow]"));
        
        // Panel Form Input (atas)
        JPanel panelForm = createFormPanel();
        add(panelForm, "wrap");
        
        // Panel Table (bawah)
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow");
    }
    
    // ========================================
    // PANEL FORM INPUT
    // ========================================
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]15[grow][]15[grow]", ""));
        
        // Styling panel (rounded corner + shadow)
        panel.putClientProperty(FlatClientProperties.STYLE, "" +
            "arc:20;" +
            "background:darken(@background,3%)");
        
        // Title
        JLabel lblTitle = new JLabel(" Form Data Kategori");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        panel.add(lblTitle, "span 4, wrap 15");
        
        // === INPUT FIELDS ===
        txtKode = new JTextField(15);
        txtNama = new JTextField(15);
        txtDeskripsi = new JTextArea(3, 15);
        txtDeskripsi.setLineWrap(true);
        txtDeskripsi.setWrapStyleWord(true);
        JScrollPane scrollDesc = new JScrollPane(txtDeskripsi);
        
        // Placeholder text
        txtKode.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: KAT001");
        txtNama.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Contoh: Elektronik");
        txtDeskripsi.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Deskripsi kategori (opsional)");
        
        // === BUTTONS ===
        btnSave = new JButton(" Simpan");
        btnUpdate = new JButton(" Update");
        btnDelete = new JButton(" Hapus");
        btnClear = new JButton(" Batal");
        
        // Button colors
        btnSave.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnUpdate.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnDelete.putClientProperty(FlatClientProperties.STYLE, "background:#f44336");
        btnClear.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        
        // === ADD TO PANEL ===
        panel.add(new JLabel("Kode Kategori:"));
        panel.add(txtKode, "grow");
        panel.add(new JLabel("Nama Kategori:"));
        panel.add(txtNama, "grow, wrap");
        
        panel.add(new JLabel("Deskripsi:"), "top");
        panel.add(scrollDesc, "span 3, grow, wrap 15");
        
        panel.add(btnSave, "span 4, split 4, grow");
        panel.add(btnUpdate, "grow");
        panel.add(btnDelete, "grow");
        panel.add(btnClear, "grow");
        
        // === EVENT LISTENERS ===
        btnSave.addActionListener(e -> saveData());
        btnUpdate.addActionListener(e -> updateData());
        btnDelete.addActionListener(e -> deleteData());
        btnClear.addActionListener(e -> clearForm());
        
        // Initial state
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        
        return panel;
    }
    
    // ========================================
    // PANEL TABLE
    // ========================================
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]15[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "" +
            "arc:20;" +
            "background:darken(@background,3%)");
        
        // Title + Search
        JLabel lblTitle = new JLabel(" Daftar Kategori");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +4");
        
        txtSearch = new JTextField(20);
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari kode, nama, atau deskripsi...");
        btnSearch = new JButton("🔍 Cari");
        
        panel.add(lblTitle, "split 3");
        panel.add(txtSearch, "grow, gapleft push");
        panel.add(btnSearch, "wrap");
        
        // === TABLE ===
        String[] columns = {"ID", "Kode Kategori", "Nama Kategori", "Deskripsi"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.getColumnModel().getColumn(0).setMaxWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(120);
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(250);
        
        table.setRowHeight(30);
        table.getTableHeader().putClientProperty(FlatClientProperties.STYLE, "height:35");
        
        JScrollPane scroll = new JScrollPane(table);
        scroll.putClientProperty(FlatClientProperties.STYLE, "arc:15");
        
        panel.add(scroll, "grow");
        
        // === EVENTS ===
        btnSearch.addActionListener(e -> searchData());
        txtSearch.addActionListener(e -> searchData());
        
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                if (evt.getClickCount() == 1) {
                    tableClick();
                }
            }
        });
        
        return panel;
    }
    
    // ========================================
    // LOAD DATA - Ambil semua data dari database
    // ========================================
    private void loadData() {
        if (dao == null) return;
        
        tableModel.setRowCount(0);
        List<Kategori> list = dao.getAll();
        
        for (Kategori k : list) {
            Object[] row = {
                k.getIdKategori(),
                k.getKodeKategori(),
                k.getNamaKategori(),
                k.getDeskripsi() == null ? "-" : k.getDeskripsi()
            };
            tableModel.addRow(row);
        }
    }
    
    // ========================================
    // SAVE DATA - Simpan data baru
    // ========================================
    private void saveData() {
        // Validasi input
        if (txtKode.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Kode kategori harus diisi!", 
                "Validasi", 
                JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        if (txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Nama kategori harus diisi!", 
                "Validasi", 
                JOptionPane.WARNING_MESSAGE);
            txtNama.requestFocus();
            return;
        }
        
        // Cek duplikat kode
        if (dao.isKodeExists(txtKode.getText().trim(), 0)) {
            JOptionPane.showMessageDialog(this, 
                "Kode kategori sudah digunakan!", 
                "Validasi", 
                JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        // Bikin object Kategori
        Kategori kategori = new Kategori();
        kategori.setKodeKategori(txtKode.getText().trim());
        kategori.setNamaKategori(txtNama.getText().trim());
        kategori.setDeskripsi(txtDeskripsi.getText().trim());
        
        // Save ke database
        if (dao.insert(kategori)) {
            JOptionPane.showMessageDialog(this, 
                " Data kategori berhasil disimpan!", 
                "Sukses", 
                JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, 
                " Gagal menyimpan data!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // UPDATE DATA - Update data yang sudah ada
    // ========================================
    private void updateData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, 
                "Pilih data yang akan diupdate!", 
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Validasi
        if (txtKode.getText().trim().isEmpty() || txtNama.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Kode dan Nama kategori harus diisi!", 
                "Validasi", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Cek duplikat (kecuali ID sendiri)
        if (dao.isKodeExists(txtKode.getText().trim(), selectedId)) {
            JOptionPane.showMessageDialog(this, 
                "Kode kategori sudah digunakan!", 
                "Validasi", 
                JOptionPane.WARNING_MESSAGE);
            txtKode.requestFocus();
            return;
        }
        
        // Bikin object Kategori
        Kategori kategori = new Kategori();
        kategori.setIdKategori(selectedId);
        kategori.setKodeKategori(txtKode.getText().trim());
        kategori.setNamaKategori(txtNama.getText().trim());
        kategori.setDeskripsi(txtDeskripsi.getText().trim());
        
        // Update ke database
        if (dao.update(kategori)) {
            JOptionPane.showMessageDialog(this, 
                " Data kategori berhasil diupdate!", 
                "Sukses", 
                JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadData();
        } else {
            JOptionPane.showMessageDialog(this, 
                " Gagal mengupdate data!", 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // DELETE DATA - Hapus data
    // ========================================
    private void deleteData() {
        if (selectedId == 0) {
            JOptionPane.showMessageDialog(this, 
                "Pilih data yang akan dihapus!", 
                "Peringatan", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Konfirmasi hapus
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Apakah Anda yakin ingin menghapus kategori ini?\n\n" +
            "⚠️ Peringatan: Barang yang menggunakan kategori ini mungkin terpengaruh!", 
            "Konfirmasi Hapus", 
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (dao.delete(selectedId)) {
                JOptionPane.showMessageDialog(this, 
                    " Data kategori berhasil dihapus!", 
                    "Sukses", 
                    JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadData();
            } else {
                JOptionPane.showMessageDialog(this, 
                    " Gagal menghapus data!\n\n" +
                    "Kemungkinan kategori masih digunakan oleh barang lain.", 
                    "Error", 
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // ========================================
    // SEARCH DATA - Cari berdasarkan keyword
    // ========================================
    private void searchData() {
        String keyword = txtSearch.getText().trim();
        
        if (keyword.isEmpty()) {
            loadData();
            return;
        }
        
        tableModel.setRowCount(0);
        List<Kategori> list = dao.search(keyword);
        
        if (list.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Data tidak ditemukan!", 
                "Pencarian", 
                JOptionPane.INFORMATION_MESSAGE);
        }
        
        for (Kategori k : list) {
            Object[] row = {
                k.getIdKategori(),
                k.getKodeKategori(),
                k.getNamaKategori(),
                k.getDeskripsi() == null ? "-" : k.getDeskripsi()
            };
            tableModel.addRow(row);
        }
    }
    
    // ========================================
    // CLEAR FORM - Reset semua input
    // ========================================
    private void clearForm() {
        txtKode.setText("");
        txtNama.setText("");
        txtDeskripsi.setText("");
        txtSearch.setText("");
        selectedId = 0;
        
        btnSave.setEnabled(true);
        btnUpdate.setEnabled(false);
        btnDelete.setEnabled(false);
        
        table.clearSelection();
        txtKode.requestFocus();
    }
    
    // ========================================
    // TABLE CLICK - Isi form saat klik row
    // ========================================
    private void tableClick() {
        int row = table.getSelectedRow();
        if (row != -1) {
            selectedId = (int) table.getValueAt(row, 0);
            txtKode.setText(table.getValueAt(row, 1).toString());
            txtNama.setText(table.getValueAt(row, 2).toString());
            
            String desc = table.getValueAt(row, 3).toString();
            txtDeskripsi.setText(desc.equals("-") ? "" : desc);
            
            // Switch button state
            btnSave.setEnabled(false);
            btnUpdate.setEnabled(true);
            btnDelete.setEnabled(true);
        }
    }
}