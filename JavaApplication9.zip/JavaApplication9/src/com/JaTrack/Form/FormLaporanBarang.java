package com.JaTrack.form;

import com.JaTrack.dao.BarangDAO;
import com.JaTrack.model.Barang;
import com.JaTrack.main.Form;
import com.formdev.flatlaf.FlatClientProperties;
import java.awt.Desktop;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import net.miginfocom.swing.MigLayout;

public class FormLaporanBarang extends Form {
    
    private JTextField txtSearch;
    private JComboBox<String> cmbFilter;
    private JButton btnTampilkan, btnPrint, btnExport, btnRefresh;
    private JTable table;
    private DefaultTableModel tableModel;
    private JLabel lblTotalBarang, lblTotalStok, lblStokRendah;
    
    private BarangDAO barangDAO;
    private Connection conn;
    
    public FormLaporanBarang() {
        initConnection();
        init();
    }
    
    private void initConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/jaws_databarang";
            String user = "root";
            String pass = "";
            
            conn = DriverManager.getConnection(url, user, pass);
            barangDAO = new BarangDAO(conn);
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, 
                "Koneksi database gagal: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void init() {
        setLayout(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]10[]"));
        
        // Panel Header
        JPanel panelHeader = createHeaderPanel();
        add(panelHeader, "wrap");
        
        // Panel Tabel
        JPanel panelTable = createTablePanel();
        add(panelTable, "grow, wrap");
        
        // Panel Summary
        JPanel panelSummary = createSummaryPanel();
        add(panelSummary, "grow");
        
        // Load data awal
        loadData();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[]10[]10[grow][]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblTitle = new JLabel(" Laporan Data Barang");
        lblTitle.putClientProperty(FlatClientProperties.STYLE, "font:bold +5");
        
        panel.add(lblTitle, "span, wrap 15");
        
        // Filter controls
        cmbFilter = new JComboBox<>(new String[]{
            "Semua Barang",
            "Stok Normal",
            "Stok Rendah (< 10)"
        });
        
        txtSearch = new JTextField();
        txtSearch.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Cari nama barang...");
        
        btnTampilkan = new JButton(" Cari");
        btnRefresh = new JButton(" Refresh");
        btnPrint = new JButton(" Print");
        btnExport = new JButton(" Export");
        
        btnTampilkan.putClientProperty(FlatClientProperties.STYLE, "background:#2196F3");
        btnRefresh.putClientProperty(FlatClientProperties.STYLE, "background:#757575");
        btnPrint.putClientProperty(FlatClientProperties.STYLE, "background:#4CAF50");
        btnExport.putClientProperty(FlatClientProperties.STYLE, "background:#FF9800");
        
        panel.add(new JLabel("Filter:"));
        panel.add(cmbFilter, "w 180!");
        panel.add(txtSearch, "grow");
        panel.add(btnTampilkan);
        panel.add(btnRefresh, "wrap");
        
        panel.add(btnPrint, "skip 2");
        panel.add(btnExport);
        
        // Event listeners
        btnTampilkan.addActionListener(e -> searchData());
        btnRefresh.addActionListener(e -> loadData());
        btnPrint.addActionListener(e -> printLaporan());
        btnExport.addActionListener(e -> exportToCSV());
        txtSearch.addActionListener(e -> searchData());
        cmbFilter.addActionListener(e -> filterData());
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow]", "[]10[grow]"));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20");
        
        JLabel lblData = new JLabel("📋 Data Barang");
        lblData.putClientProperty(FlatClientProperties.STYLE, "font:bold +3");
        panel.add(lblData, "wrap");
        
        // Table
        String[] columns = {"No", "Kode Barang", "Nama Barang", "Kategori", "Stok", "Satuan", "Harga", "Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.getColumnModel().getColumn(0).setMaxWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(80);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        table.getColumnModel().getColumn(7).setPreferredWidth(100);
        
        JScrollPane scroll = new JScrollPane(table);
        panel.add(scroll, "grow");
        
        return panel;
    }
    
    private JPanel createSummaryPanel() {
        JPanel panel = new JPanel(new MigLayout("fill, insets 15", "[grow][grow][grow]", ""));
        panel.putClientProperty(FlatClientProperties.STYLE, "arc:20;background:#E3F2FD");
        
        lblTotalBarang = new JLabel(" Total Jenis Barang: 0");
        lblTotalBarang.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblTotalStok = new JLabel(" Total Stok: 0");
        lblTotalStok.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        lblStokRendah = new JLabel(" Stok Rendah: 0");
        lblStokRendah.putClientProperty(FlatClientProperties.STYLE, "font:bold +2");
        
        panel.add(lblTotalBarang, "grow");
        panel.add(lblTotalStok, "grow");
        panel.add(lblStokRendah, "grow");
        
        return panel;
    }
    
    private void loadData() {
        tableModel.setRowCount(0);
        
        try {
            List<Barang> list = barangDAO.getAll();
            int no = 1;
            int totalStok = 0;
            int stokRendah = 0;
            
            for (Barang b : list) {
                String status = b.getStok() < 10 ? " Rendah" : " Normal";
                if (b.getStok() < 10) stokRendah++;
                
                tableModel.addRow(new Object[]{
                    no++,
                    b.getKodeBarang(),
                    b.getNamaBarang(),
                    b.getKategori(),
                    b.getStok(),
                    b.getSatuan(),
                    String.format("Rp %,.0f", b.getHarga()),
                    status
                });
                
                totalStok += b.getStok();
            }
            
            // Update summary
            lblTotalBarang.setText(" Total Jenis Barang: " + list.size());
            lblTotalStok.setText(" Total Stok: " + totalStok);
            lblStokRendah.setText("Stok Rendah: " + stokRendah);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
    
    private void filterData() {
        int filterIndex = cmbFilter.getSelectedIndex();
        tableModel.setRowCount(0);
        
        try {
            List<Barang> list = barangDAO.getAll();
            int no = 1;
            int totalStok = 0;
            int stokRendah = 0;
            
            for (Barang b : list) {
                boolean tampilkan = false;
                
                if (filterIndex == 0) { // Semua
                    tampilkan = true;
                } else if (filterIndex == 1) { // Stok Normal
                    tampilkan = b.getStok() >= 10;
                } else if (filterIndex == 2) { // Stok Rendah
                    tampilkan = b.getStok() < 10;
                }
                
                if (tampilkan) {
                    String status = b.getStok() < 10 ? " Rendah" : " Normal";
                    if (b.getStok() < 10) stokRendah++;
                    
                    tableModel.addRow(new Object[]{
                        no++,
                        b.getKodeBarang(),
                        b.getNamaBarang(),
                        b.getKategori(),
                        b.getStok(),
                        b.getSatuan(),
                        String.format("Rp %,.0f", b.getHarga()),
                        status
                    });
                    
                    totalStok += b.getStok();
                }
            }
            
            // Update summary
            lblTotalBarang.setText("📦 Total Jenis Barang: " + (no - 1));
            lblTotalStok.setText("📊 Total Stok: " + totalStok);
            lblStokRendah.setText("⚠️ Stok Rendah: " + stokRendah);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void searchData() {
        String keyword = txtSearch.getText().trim();
        
        if (keyword.isEmpty()) {
            loadData();
            return;
        }
        
        tableModel.setRowCount(0);
        
        try {
            List<Barang> list = barangDAO.search(keyword);
            int no = 1;
            int totalStok = 0;
            int stokRendah = 0;
            
            for (Barang b : list) {
                String status = b.getStok() < 10 ? " Rendah" : " Normal";
                if (b.getStok() < 10) stokRendah++;
                
                tableModel.addRow(new Object[]{
                    no++,
                    b.getKodeBarang(),
                    b.getNamaBarang(),
                    b.getKategori(),
                    b.getStok(),
                    b.getSatuan(),
                    String.format("Rp %,.0f", b.getHarga()),
                    status
                });
                
                totalStok += b.getStok();
            }
            
            lblTotalBarang.setText(" Total Jenis Barang: " + list.size());
            lblTotalStok.setText(" Total Stok: " + totalStok);
            lblStokRendah.setText(" Stok Rendah: " + stokRendah);
            
            if (list.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Data tidak ditemukan!");
            }
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }
    
    private void printLaporan() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-print!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            String tanggal = new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date());
            
            MessageFormat header = new MessageFormat("LAPORAN DATA BARANG\nDicetak: " + tanggal);
            MessageFormat footer = new MessageFormat("Halaman {0}");
            
            boolean complete = table.print(
                JTable.PrintMode.FIT_WIDTH,
                header,
                footer,
                true,
                null,
                true,
                null
            );
            
            if (complete) {
                JOptionPane.showMessageDialog(this, " Print berhasil!");
            } else {
                JOptionPane.showMessageDialog(this, " Print dibatalkan!");
            }
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(this, "Error printing: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void exportToCSV() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Tidak ada data untuk di-export!", "Info", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Simpan Laporan");
        fileChooser.setSelectedFile(new File("Laporan_Barang_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".csv"));
        
        int userSelection = fileChooser.showSaveDialog(this);
        
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();
            
            try (FileOutputStream fos = new FileOutputStream(fileToSave)) {
                StringBuilder sb = new StringBuilder();
                
                // Header
                sb.append("LAPORAN DATA BARANG\n");
                sb.append("Tanggal: ").append(new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date())).append("\n\n");
                
                // Column headers
                for (int i = 0; i < tableModel.getColumnCount(); i++) {
                    sb.append(tableModel.getColumnName(i));
                    if (i < tableModel.getColumnCount() - 1) sb.append(",");
                }
                sb.append("\n");
                
                // Data rows
                for (int row = 0; row < tableModel.getRowCount(); row++) {
                    for (int col = 0; col < tableModel.getColumnCount(); col++) {
                        Object value = tableModel.getValueAt(row, col);
                        String text = value != null ? value.toString().replace(",", ";") : "";
                        sb.append(text);
                        if (col < tableModel.getColumnCount() - 1) sb.append(",");
                    }
                    sb.append("\n");
                }
                
                // Summary
                sb.append("\n");
                sb.append(lblTotalBarang.getText().replace(" ", "")).append("\n");
                sb.append(lblTotalStok.getText().replace(" ", "")).append("\n");
                sb.append(lblStokRendah.getText().replace(" ", "")).append("\n");
                
                fos.write(sb.toString().getBytes());
                
                JOptionPane.showMessageDialog(this, " File berhasil disimpan!\n" + fileToSave.getAbsolutePath());
                
                if (Desktop.isDesktopSupported()) {
                    Desktop.getDesktop().open(fileToSave);
                }
                
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error export: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}