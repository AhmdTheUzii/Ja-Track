package com.JaTrack.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class DatabaseConnection {
    
    private static DatabaseConnection instance;
    private Connection connection;
    
    // ========================================
    // DATABASE CONFIG - SESUAIKAN DENGAN PUNYA LO!
    // ========================================
    private static final String DB_HOST = "localhost";
    private static final String DB_PORT = "3306";
    private static final String DB_NAME = "jaws_databarang";
    private static final String DB_USER = "root";
    private static final String DB_PASS = ""; // ⚠️ Ganti kalau MySQL lo ada password!
    
    // ✅ Gunakan driver yang lebih baru (com.mysql.cj.jdbc.Driver)
    private static final String DB_URL = "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME 
        + "?useSSL=false"              // Disable SSL untuk localhost
        + "&serverTimezone=Asia/Jakarta"  // Set timezone
        + "&allowPublicKeyRetrieval=true"; // Allow public key retrieval
    
    // Private constructor (Singleton Pattern)
    private DatabaseConnection() {
        try {
            // ✅ Load MySQL JDBC Driver (versi baru)
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            // ✅ Bikin connection
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            
            System.out.println("✅ Database connected successfully!");
            System.out.println("📊 Database: " + DB_NAME);
            
        } catch (ClassNotFoundException e) {
            // ✅ Fallback ke driver lama kalau driver baru ga ada
            try {
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection(
                    "jdbc:mysql://" + DB_HOST + ":" + DB_PORT + "/" + DB_NAME,
                    DB_USER, DB_PASS
                );
                System.out.println("✅ Database connected (using legacy driver)");
            } catch (Exception ex) {
                showDriverError();
                ex.printStackTrace();
            }
            
        } catch (SQLException e) {
            showConnectionError(e);
            e.printStackTrace();
        }
    }
    
    // ✅ Error messages yang lebih informatif
    private void showDriverError() {
        JOptionPane.showMessageDialog(null, 
            "❌ MySQL JDBC Driver not found!\n\n" + 
            "Solusi:\n" +
            "1. Download: mysql-connector-java-8.0.33.jar\n" +
            "2. Di NetBeans: klik kanan project → Properties\n" +
            "3. Libraries → Add JAR/Folder → pilih file .jar\n" +
            "4. Clean and Build project\n\n" +
            "Download: https://dev.mysql.com/downloads/connector/j/",
            "Driver Error",
            JOptionPane.ERROR_MESSAGE);
    }
    
    private void showConnectionError(SQLException e) {
        String errorMsg = "❌ Failed to connect to database!\n\n";
        
        // ✅ Deteksi jenis error dan kasih solusi spesifik
        if (e.getMessage().contains("Access denied")) {
            errorMsg += "🔐 Username atau Password salah!\n\n" +
                       "Cek di DatabaseConnection.java:\n" +
                       "- DB_USER = \"" + DB_USER + "\"\n" +
                       "- DB_PASS = \"" + DB_PASS + "\"";
        } else if (e.getMessage().contains("Unknown database")) {
            errorMsg += "📂 Database '" + DB_NAME + "' tidak ditemukan!\n\n" +
                       "Solusi:\n" +
                       "1. Buka phpMyAdmin/MySQL Workbench\n" +
                       "2. Buat database baru: CREATE DATABASE " + DB_NAME + ";\n" +
                       "3. Import SQL file (kalau ada)";
        } else if (e.getMessage().contains("Communications link failure")) {
            errorMsg += "🔌 MySQL service tidak running!\n\n" +
                       "Solusi:\n" +
                       "1. Buka XAMPP/WAMP\n" +
                       "2. Start MySQL service\n" +
                       "3. Cek di Task Manager apakah mysqld.exe running";
        } else {
            errorMsg += "Error: " + e.getMessage() + "\n\n" +
                       "Checklist:\n" +
                       "✓ MySQL service running?\n" +
                       "✓ Database '" + DB_NAME + "' exists?\n" +
                       "✓ Username & password correct?";
        }
        
        JOptionPane.showMessageDialog(null, errorMsg,
            "Database Connection Error",
            JOptionPane.ERROR_MESSAGE);
    }
    
    // ✅ Get instance (Singleton Pattern)
    public static DatabaseConnection getInstance() {
        if (instance == null) {
            synchronized (DatabaseConnection.class) {
                if (instance == null) {
                    instance = new DatabaseConnection();
                }
            }
        }
        return instance;
    }
    
    // ✅ Get connection dengan auto-reconnect
    public Connection getConnection() {
        try {
            // Cek kalau connection mati atau null, bikin baru
            if (connection == null || connection.isClosed()) {
                System.out.println("⚠️ Connection was closed, reconnecting...");
                connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                System.out.println("✅ Reconnected successfully!");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error reconnecting to database: " + e.getMessage());
            JOptionPane.showMessageDialog(null, 
                "❌ Error reconnecting to database!\n" + e.getMessage(),
                "Connection Error",
                JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return connection;
    }
    
    // ✅ Close connection (dipanggil saat aplikasi exit)
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("✅ Database connection closed.");
            }
        } catch (SQLException e) {
            System.err.println("❌ Error closing connection: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // ✅ Test connection (untuk debugging)
    public boolean testConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                // Test dengan query sederhana
                connection.createStatement().execute("SELECT 1");
                System.out.println("✅ Connection test: PASSED");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("❌ Connection test: FAILED - " + e.getMessage());
        }
        return false;
    }
    
    // ✅ Get database info (untuk debugging)
    public String getDatabaseInfo() {
        try {
            if (connection != null && !connection.isClosed()) {
                return String.format(
                    "Database: %s\nHost: %s:%s\nUser: %s\nDriver: %s",
                    DB_NAME, DB_HOST, DB_PORT, DB_USER,
                    connection.getMetaData().getDriverName()
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Connection not available";
    }
}