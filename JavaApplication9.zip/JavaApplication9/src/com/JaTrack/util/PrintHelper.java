package com.JaTrack.util;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.print.*;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Helper untuk Print/Export Laporan
 * Pakai Java Print API (built-in, no external library)
 */
public class PrintHelper {
    
    // ========================================
    // PRINT TABLE ke Printer
    // ========================================
    public static void printTable(JTable table, String title) {
        try {
            // Print dengan header & footer
            MessageFormat header = new MessageFormat(title);
            MessageFormat footer = new MessageFormat("Page {0}");
            
            // Show print dialog
            table.print(JTable.PrintMode.FIT_WIDTH, header, footer);
            
        } catch (PrinterException e) {
            JOptionPane.showMessageDialog(null, 
                "Error saat print: " + e.getMessage(),
                "Print Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // PRINT dengan Custom Format
    // ========================================
    public static void printReport(String judul, String[] columns, Object[][] data) {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new Printable() {
            @Override
            public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
                if (pageIndex > 0) {
                    return NO_SUCH_PAGE;
                }
                
                Graphics2D g2d = (Graphics2D) graphics;
                g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
                
                // Font
                Font titleFont = new Font("Arial", Font.BOLD, 16);
                Font headerFont = new Font("Arial", Font.BOLD, 10);
                Font dataFont = new Font("Arial", Font.PLAIN, 9);
                
                int y = 50;
                int lineHeight = 20;
                
                // Header
                g2d.setFont(titleFont);
                g2d.drawString(judul, 50, y);
                y += 30;
                
                // Tanggal print
                g2d.setFont(dataFont);
                String tanggal = new SimpleDateFormat("dd MMMM yyyy HH:mm").format(new Date());
                g2d.drawString("Dicetak pada: " + tanggal, 50, y);
                y += 30;
                
                // Table Header
                g2d.setFont(headerFont);
                int x = 50;
                for (String col : columns) {
                    g2d.drawString(col, x, y);
                    x += 100;
                }
                y += lineHeight;
                
                // Line separator
                g2d.drawLine(50, y, 500, y);
                y += 10;
                
                // Table Data
                g2d.setFont(dataFont);
                for (Object[] row : data) {
                    x = 50;
                    for (Object cell : row) {
                        String value = cell != null ? cell.toString() : "";
                        if (value.length() > 15) {
                            value = value.substring(0, 12) + "...";
                        }
                        g2d.drawString(value, x, y);
                        x += 100;
                    }
                    y += lineHeight;
                    
                    // Cek kalau melebihi page
                    if (y > pageFormat.getImageableHeight() - 50) {
                        break;
                    }
                }
                
                // Footer
                y = (int) pageFormat.getImageableHeight() - 20;
                g2d.drawString("JA-Track v1.0 - Warehouse Management System", 50, y);
                
                return PAGE_EXISTS;
            }
        });
        
        // Show print dialog
        if (job.printDialog()) {
            try {
                job.print();
                JOptionPane.showMessageDialog(null, 
                    "✅ Dokumen berhasil dikirim ke printer!",
                    "Print Sukses",
                    JOptionPane.INFORMATION_MESSAGE);
            } catch (PrinterException e) {
                JOptionPane.showMessageDialog(null, 
                    "Error: " + e.getMessage(),
                    "Print Error",
                    JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    // ========================================
    // EXPORT TABLE to CSV
    // ========================================
    public static void exportToCSV(JTable table, String filename) {
        try {
            java.io.FileWriter fw = new java.io.FileWriter(filename + ".csv");
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            
            // Write headers
            for (int i = 0; i < model.getColumnCount(); i++) {
                fw.write(model.getColumnName(i));
                if (i < model.getColumnCount() - 1) {
                    fw.write(",");
                }
            }
            fw.write("\n");
            
            // Write data
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    Object value = model.getValueAt(i, j);
                    fw.write(value != null ? value.toString() : "");
                    if (j < model.getColumnCount() - 1) {
                        fw.write(",");
                    }
                }
                fw.write("\n");
            }
            
            fw.close();
            
            JOptionPane.showMessageDialog(null, 
                "✅ File berhasil di-export!\n\nLokasi: " + filename + ".csv",
                "Export Sukses",
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, 
                "Error export: " + e.getMessage(),
                "Export Error",
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========================================
    // PREVIEW sebelum Print
    // ========================================
    public static void showPrintPreview(JTable table, String title) {
        JDialog dialog = new JDialog();
        dialog.setTitle("Print Preview - " + title);
        dialog.setSize(800, 600);
        dialog.setModal(true);
        dialog.setLocationRelativeTo(null);
        
        JScrollPane scroll = new JScrollPane(table);
        dialog.add(scroll, BorderLayout.CENTER);
        
        JPanel buttonPanel = new JPanel();
        JButton btnPrint = new JButton("🖨️ Print");
        JButton btnClose = new JButton("❌ Close");
        
        btnPrint.addActionListener(e -> {
            printTable(table, title);
            dialog.dispose();
        });
        
        btnClose.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(btnPrint);
        buttonPanel.add(btnClose);
        dialog.add(buttonPanel, BorderLayout.SOUTH);
        
        dialog.setVisible(true);
    }
}

/*
 * CARA PAKAI:
 * 
 * // 1. Print table langsung
 * PrintHelper.printTable(table, "Laporan Barang");
 * 
 * // 2. Print dengan custom format
 * String[] columns = {"Kode", "Nama", "Stok"};
 * Object[][] data = {{"BRG001", "TV", 10}, {"BRG002", "Kulkas", 5}};
 * PrintHelper.printReport("LAPORAN BARANG", columns, data);
 * 
 * // 3. Export to CSV
 * PrintHelper.exportToCSV(table, "laporan_barang");
 * 
 * // 4. Preview sebelum print
 * PrintHelper.showPrintPreview(table, "Laporan Barang");
 */