package com.JaTrack.dao;

import com.JaTrack.model.BarangMasuk;
import com.JaTrack.model.BarangKeluar;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class TransaksiDAO {
    
    private Connection conn;
    
    public TransaksiDAO(Connection conn) {
        this.conn = conn;
    }
    
    /**
     * ==========================================
     * BARANG MASUK - AUTO TAMBAH STOK
     * ==========================================
     */
    
    public boolean insertBarangMasuk(BarangMasuk barangMasuk) {
        String sqlInsert = "INSERT INTO barang_masuk (tanggal_masuk, id_barang, nama_barang, jumlah, satuan, supplier, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlUpdateStok = "UPDATE barang SET stok = stok + ? WHERE id_barang = ?";
        
        try {
            conn.setAutoCommit(false);
            
            // 1. Insert barang masuk
            PreparedStatement psInsert = conn.prepareStatement(sqlInsert);
            psInsert.setDate(1, new java.sql.Date(barangMasuk.getTanggalMasuk().getTime()));
            psInsert.setInt(2, barangMasuk.getIdBarang());
            psInsert.setString(3, barangMasuk.getNamaBarang());
            psInsert.setInt(4, barangMasuk.getJumlah());
            psInsert.setString(5, barangMasuk.getSatuan());
            psInsert.setString(6, barangMasuk.getSupplier());
            psInsert.setString(7, barangMasuk.getKeterangan());
            psInsert.executeUpdate();
            
            // 2. UPDATE STOK BARANG (TAMBAH)
            PreparedStatement psUpdate = conn.prepareStatement(sqlUpdateStok);
            psUpdate.setInt(1, barangMasuk.getJumlah());
            psUpdate.setInt(2, barangMasuk.getIdBarang());
            psUpdate.executeUpdate();
            
            conn.commit();
            conn.setAutoCommit(true);
            return true;
            
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null, "Error Insert Barang Masuk: " + e.getMessage());
            return false;
        }
    }
    
    public List<BarangMasuk> getAllBarangMasuk() {
        List<BarangMasuk> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_masuk ORDER BY id_masuk DESC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                BarangMasuk bm = new BarangMasuk();
                bm.setIdMasuk(rs.getInt("id_masuk"));
                bm.setTanggalMasuk(rs.getDate("tanggal_masuk"));
                bm.setIdBarang(rs.getInt("id_barang"));
                bm.setNamaBarang(rs.getString("nama_barang"));
                bm.setJumlah(rs.getInt("jumlah"));
                bm.setSatuan(rs.getString("satuan"));
                bm.setSupplier(rs.getString("supplier"));
                bm.setKeterangan(rs.getString("keterangan"));
                list.add(bm);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get Barang Masuk: " + e.getMessage());
        }
        return list;
    }
    
    public boolean deleteBarangMasuk(int idMasuk) {
        String sqlGetData = "SELECT id_barang, jumlah FROM barang_masuk WHERE id_masuk = ?";
        String sqlDelete = "DELETE FROM barang_masuk WHERE id_masuk = ?";
        String sqlRestoreStok = "UPDATE barang SET stok = stok - ? WHERE id_barang = ?";
        
        try {
            conn.setAutoCommit(false);
            
            // 1. Ambil data barang masuk
            PreparedStatement psGet = conn.prepareStatement(sqlGetData);
            psGet.setInt(1, idMasuk);
            ResultSet rs = psGet.executeQuery();
            
            int idBarang = 0;
            int jumlah = 0;
            if (rs.next()) {
                idBarang = rs.getInt("id_barang");
                jumlah = rs.getInt("jumlah");
            }
            
            // 2. Restore stok (kurangi karena barang masuk dibatalkan)
            PreparedStatement psRestore = conn.prepareStatement(sqlRestoreStok);
            psRestore.setInt(1, jumlah);
            psRestore.setInt(2, idBarang);
            psRestore.executeUpdate();
            
            // 3. Delete barang masuk
            PreparedStatement psDelete = conn.prepareStatement(sqlDelete);
            psDelete.setInt(1, idMasuk);
            int result = psDelete.executeUpdate();
            
            conn.commit();
            conn.setAutoCommit(true);
            return result > 0;
            
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null, "Error Delete Barang Masuk: " + e.getMessage());
            return false;
        }
    }
    
    public List<BarangMasuk> searchBarangMasuk(String keyword) {
        List<BarangMasuk> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_masuk WHERE nama_barang LIKE ? OR supplier LIKE ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangMasuk bm = new BarangMasuk();
                bm.setIdMasuk(rs.getInt("id_masuk"));
                bm.setTanggalMasuk(rs.getDate("tanggal_masuk"));
                bm.setIdBarang(rs.getInt("id_barang"));
                bm.setNamaBarang(rs.getString("nama_barang"));
                bm.setJumlah(rs.getInt("jumlah"));
                bm.setSatuan(rs.getString("satuan"));
                bm.setSupplier(rs.getString("supplier"));
                bm.setKeterangan(rs.getString("keterangan"));
                list.add(bm);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Search: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * ==========================================
     * BARANG KELUAR - AUTO KURANGI STOK
     * ==========================================
     */
    
    public boolean insertBarangKeluar(BarangKeluar barangKeluar) {
        String sqlInsert = "INSERT INTO barang_keluar (tanggal_keluar, id_produksi, nama_barang, jumlah, satuan, customer, keterangan) VALUES (?, ?, ?, ?, ?, ?, ?)";
        // Note: Stok barang keluar dikurangi dari hasil produksi, bukan dari tabel barang
        // Jadi kita cuma insert aja, ga update stok barang
        
        try {
            PreparedStatement ps = conn.prepareStatement(sqlInsert);
            ps.setDate(1, new java.sql.Date(barangKeluar.getTanggalKeluar().getTime()));
            ps.setInt(2, barangKeluar.getIdProduksi());
            ps.setString(3, barangKeluar.getNamaBarang());
            ps.setInt(4, barangKeluar.getJumlah());
            ps.setString(5, barangKeluar.getSatuan());
            ps.setString(6, barangKeluar.getCustomer());
            ps.setString(7, barangKeluar.getKeterangan());
            
            int result = ps.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Insert Barang Keluar: " + e.getMessage());
            return false;
        }
    }
    
    public List<BarangKeluar> getAllBarangKeluar() {
        List<BarangKeluar> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_keluar ORDER BY id_keluar DESC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                BarangKeluar bk = new BarangKeluar();
                bk.setIdKeluar(rs.getInt("id_keluar"));
                bk.setTanggalKeluar(rs.getDate("tanggal_keluar"));
                bk.setIdProduksi(rs.getInt("id_produksi"));
                bk.setNamaBarang(rs.getString("nama_barang"));
                bk.setJumlah(rs.getInt("jumlah"));
                bk.setSatuan(rs.getString("satuan"));
                bk.setCustomer(rs.getString("customer"));
                bk.setKeterangan(rs.getString("keterangan"));
                list.add(bk);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get Barang Keluar: " + e.getMessage());
        }
        return list;
    }
    
    public boolean deleteBarangKeluar(int idKeluar) {
        String sql = "DELETE FROM barang_keluar WHERE id_keluar = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idKeluar);
            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Delete: " + e.getMessage());
            return false;
        }
    }
    
    public List<BarangKeluar> searchBarangKeluar(String keyword) {
        List<BarangKeluar> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_keluar WHERE nama_barang LIKE ? OR customer LIKE ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangKeluar bk = new BarangKeluar();
                bk.setIdKeluar(rs.getInt("id_keluar"));
                bk.setTanggalKeluar(rs.getDate("tanggal_keluar"));
                bk.setIdProduksi(rs.getInt("id_produksi"));
                bk.setNamaBarang(rs.getString("nama_barang"));
                bk.setJumlah(rs.getInt("jumlah"));
                bk.setSatuan(rs.getString("satuan"));
                bk.setCustomer(rs.getString("customer"));
                bk.setKeterangan(rs.getString("keterangan"));
                list.add(bk);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Search: " + e.getMessage());
        }
        return list;
    }
}