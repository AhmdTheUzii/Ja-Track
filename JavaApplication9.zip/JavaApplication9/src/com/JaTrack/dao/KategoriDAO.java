package com.JaTrack.dao;

import com.JaTrack.model.Kategori;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class KategoriDAO {
    
    private Connection conn; // Koneksi ke database
    
    // Constructor - terima koneksi dari luar
    public KategoriDAO(Connection conn) {
        this.conn = conn;
    }
    
    // ========================================
    // CREATE - Tambah data baru ke database
    // ========================================
    public boolean insert(Kategori kategori) {
        // Query SQL untuk insert
        String sql = "INSERT INTO kategori (kode_kategori, nama_kategori, deskripsi) VALUES (?, ?, ?)";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            // Isi parameter (tanda tanya di query)
            ps.setString(1, kategori.getKodeKategori());  // Parameter 1
            ps.setString(2, kategori.getNamaKategori());  // Parameter 2
            ps.setString(3, kategori.getDeskripsi());     // Parameter 3
            
            // Eksekusi query
            int result = ps.executeUpdate();
            return result > 0; // Return true kalau berhasil
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Insert: " + e.getMessage());
            return false;
        }
    }
    
    // ========================================
    // READ - Ambil semua data dari database
    // ========================================
    public List<Kategori> getAll() {
        List<Kategori> list = new ArrayList<>(); // List untuk nyimpen hasil
        String sql = "SELECT * FROM kategori ORDER BY id_kategori DESC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            // Loop semua baris hasil query
            while (rs.next()) {
                // Bikin object Kategori baru per baris
                Kategori kategori = new Kategori();
                kategori.setIdKategori(rs.getInt("id_kategori"));
                kategori.setKodeKategori(rs.getString("kode_kategori"));
                kategori.setNamaKategori(rs.getString("nama_kategori"));
                kategori.setDeskripsi(rs.getString("deskripsi"));
                
                // Masukin ke list
                list.add(kategori);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get All: " + e.getMessage());
        }
        return list; // Return list berisi semua data
    }
    
    // ========================================
    // UPDATE - Update data yang udah ada
    // ========================================
    public boolean update(Kategori kategori) {
        String sql = "UPDATE kategori SET kode_kategori=?, nama_kategori=?, deskripsi=? WHERE id_kategori=?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kategori.getKodeKategori());
            ps.setString(2, kategori.getNamaKategori());
            ps.setString(3, kategori.getDeskripsi());
            ps.setInt(4, kategori.getIdKategori()); // WHERE clause
            
            int result = ps.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Update: " + e.getMessage());
            return false;
        }
    }
    
    // ========================================
    // DELETE - Hapus data dari database
    // ========================================
    public boolean delete(int idKategori) {
        String sql = "DELETE FROM kategori WHERE id_kategori=?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idKategori);
            int result = ps.executeUpdate();
            return result > 0;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Delete: " + e.getMessage());
            return false;
        }
    }
    
    // ========================================
    // SEARCH - Cari data berdasarkan keyword
    // ========================================
    public List<Kategori> search(String keyword) {
        List<Kategori> list = new ArrayList<>();
        // LIKE = mirip/mengandung kata
        String sql = "SELECT * FROM kategori WHERE kode_kategori LIKE ? OR nama_kategori LIKE ? OR deskripsi LIKE ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = "%" + keyword + "%"; // % = wildcard (sebelum/sesudah kata)
            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Kategori kategori = new Kategori();
                kategori.setIdKategori(rs.getInt("id_kategori"));
                kategori.setKodeKategori(rs.getString("kode_kategori"));
                kategori.setNamaKategori(rs.getString("nama_kategori"));
                kategori.setDeskripsi(rs.getString("deskripsi"));
                list.add(kategori);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Search: " + e.getMessage());
        }
        return list;
    }
    
    // ========================================
    // VALIDASI - Cek duplikat kode kategori
    // ========================================
    public boolean isKodeExists(String kodeKategori, int excludeId) {
        // excludeId = ID yang dikecualikan (untuk update, jangan cek ID sendiri)
        String sql = "SELECT COUNT(*) FROM kategori WHERE kode_kategori = ? AND id_kategori != ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, kodeKategori);
            ps.setInt(2, excludeId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0; // True kalau ada data
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Check Kode: " + e.getMessage());
        }
        return false;
    }
}