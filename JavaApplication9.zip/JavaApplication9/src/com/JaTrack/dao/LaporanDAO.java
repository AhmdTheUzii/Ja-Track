package com.JaTrack.dao;

import com.JaTrack.model.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * DAO khusus untuk mengambil data laporan
 * Berisi query-query yang dioptimasi untuk reporting
 */
public class LaporanDAO {
    
    private Connection conn;
    
    public LaporanDAO(Connection conn) {
        this.conn = conn;
    }
    
    /**
     * =========================================
     * LAPORAN BARANG
     * =========================================
     */
    
    public List<Barang> getAllBarang() {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT * FROM barang ORDER BY nama_barang ASC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Barang b = new Barang();
                b.setIdBarang(rs.getInt("id_barang"));
                b.setKodeBarang(rs.getString("kode_barang"));
                b.setNamaBarang(rs.getString("nama_barang"));
                b.setKategori(rs.getString("kategori"));
                b.setStok(rs.getInt("stok"));
                b.setHarga(rs.getDouble("harga"));
                b.setSatuan(rs.getString("satuan"));
                list.add(b);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error get barang: " + e.getMessage());
        }
        return list;
    }
    
    public List<Barang> getBarangStokRendah(int batasStok) {
        List<Barang> list = new ArrayList<>();
        String sql = "SELECT * FROM barang WHERE stok < ? ORDER BY stok ASC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, batasStok);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Barang b = new Barang();
                b.setIdBarang(rs.getInt("id_barang"));
                b.setKodeBarang(rs.getString("kode_barang"));
                b.setNamaBarang(rs.getString("nama_barang"));
                b.setKategori(rs.getString("kategori"));
                b.setStok(rs.getInt("stok"));
                b.setHarga(rs.getDouble("harga"));
                b.setSatuan(rs.getString("satuan"));
                list.add(b);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * =========================================
     * LAPORAN TRANSAKSI
     * =========================================
     */
    
    public List<BarangMasuk> getBarangMasukByPeriode(Date dari, Date sampai) {
        List<BarangMasuk> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_masuk WHERE tanggal_masuk BETWEEN ? AND ? ORDER BY tanggal_masuk DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangMasuk bm = new BarangMasuk();
                bm.setIdMasuk(rs.getInt("id_masuk"));
                bm.setTanggalMasuk(rs.getDate("tanggal_masuk"));
                bm.setIdBarang(rs.getInt("id_barang"));
                bm.setNamaBarang(rs.getString("nama_barang"));
                bm.setJumlah(rs.getInt("jumlah"));
                bm.setSatuan(rs.getString("satuan"));
                bm.setSupplier(rs.getString("supplier"));
                bm.setKeterangan(rs.getString("keterangan"));
                list.add(bm);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    public List<BarangKeluar> getBarangKeluarByPeriode(Date dari, Date sampai) {
        List<BarangKeluar> list = new ArrayList<>();
        String sql = "SELECT * FROM barang_keluar WHERE tanggal_keluar BETWEEN ? AND ? ORDER BY tanggal_keluar DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                BarangKeluar bk = new BarangKeluar();
                bk.setIdKeluar(rs.getInt("id_keluar"));
                bk.setTanggalKeluar(rs.getDate("tanggal_keluar"));
                bk.setIdProduksi(rs.getInt("id_produksi"));
                bk.setNamaBarang(rs.getString("nama_barang"));
                bk.setJumlah(rs.getInt("jumlah"));
                bk.setSatuan(rs.getString("satuan"));
                bk.setCustomer(rs.getString("customer"));
                bk.setKeterangan(rs.getString("keterangan"));
                list.add(bk);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * =========================================
     * LAPORAN PRODUKSI
     * =========================================
     */
    
    public List<Produksi> getProduksiByPeriode(Date dari, Date sampai) {
        List<Produksi> list = new ArrayList<>();
        String sql = "SELECT * FROM produksi WHERE tanggal_produksi BETWEEN ? AND ? ORDER BY tanggal_produksi DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Produksi p = new Produksi();
                p.setIdProduksi(rs.getInt("id_produksi"));
                p.setTanggalProduksi(rs.getDate("tanggal_produksi"));
                p.setHasilProduksi(rs.getString("hasil_produksi"));
                p.setKeterangan(rs.getString("keterangan"));
                list.add(p);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    public List<DetailProduksi> getDetailProduksi(int idProduksi) {
        List<DetailProduksi> list = new ArrayList<>();
        String sql = "SELECT * FROM detail_produksi WHERE id_produksi = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProduksi);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                DetailProduksi detail = new DetailProduksi();
                detail.setIdDetail(rs.getInt("id_detail"));
                detail.setIdProduksi(rs.getInt("id_produksi"));
                detail.setIdBarang(rs.getInt("id_barang"));
                detail.setNamaBarang(rs.getString("nama_barang"));
                detail.setJumlahDigunakan(rs.getInt("jumlah_digunakan"));
                detail.setSatuan(rs.getString("satuan"));
                list.add(detail);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * Laporan produksi dengan detail bahan (JOIN query)
     */
    public List<Object[]> getLaporanProduksiLengkap(Date dari, Date sampai) {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT p.id_produksi, p.tanggal_produksi, p.hasil_produksi, " +
                     "COUNT(dp.id_detail) as jumlah_bahan, p.keterangan " +
                     "FROM produksi p " +
                     "LEFT JOIN detail_produksi dp ON p.id_produksi = dp.id_produksi " +
                     "WHERE p.tanggal_produksi BETWEEN ? AND ? " +
                     "GROUP BY p.id_produksi " +
                     "ORDER BY p.tanggal_produksi DESC";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Object[] row = new Object[6];
                row[0] = rs.getInt("id_produksi");
                row[1] = rs.getDate("tanggal_produksi");
                row[2] = rs.getString("hasil_produksi");
                row[3] = rs.getInt("jumlah_bahan");
                row[4] = rs.getString("keterangan");
                list.add(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * =========================================
     * LAPORAN DISTRIBUTOR
     * =========================================
     */
    
    public List<Distributor> getAllDistributor() {
        List<Distributor> list = new ArrayList<>();
        String sql = "SELECT * FROM distributor ORDER BY nama_distributor ASC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Distributor d = new Distributor();
                d.setIdDistributor(rs.getInt("id_distributor"));
                d.setNamaDistributor(rs.getString("nama_distributor"));
                d.setAlamat(rs.getString("alamat"));
                d.setNoTelepon(rs.getString("no_telepon"));
                d.setKontakPerson(rs.getString("kontak_person"));
                d.setJenisBarang(rs.getString("jenis_barang"));
                list.add(d);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * Laporan distributor dengan total transaksi (JOIN query)
     */
    public List<Object[]> getLaporanDistributorLengkap() {
        List<Object[]> list = new ArrayList<>();
        String sql = "SELECT d.id_distributor, d.nama_distributor, d.alamat, " +
                     "d.no_telepon, d.kontak_person, d.jenis_barang, " +
                     "COUNT(bm.id_masuk) as total_transaksi, " +
                     "COALESCE(SUM(bm.jumlah), 0) as total_barang " +
                     "FROM distributor d " +
                     "LEFT JOIN barang_masuk bm ON d.nama_distributor = bm.supplier " +
                     "GROUP BY d.id_distributor " +
                     "ORDER BY d.nama_distributor ASC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Object[] row = new Object[8];
                row[0] = rs.getInt("id_distributor");
                row[1] = rs.getString("nama_distributor");
                row[2] = rs.getString("alamat");
                row[3] = rs.getString("no_telepon");
                row[4] = rs.getString("kontak_person");
                row[5] = rs.getString("jenis_barang");
                row[6] = rs.getInt("total_transaksi");
                row[7] = rs.getInt("total_barang");
                list.add(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * =========================================
     * SUMMARY / STATISTIK
     * =========================================
     */
    
    public int getTotalJenisBarang() {
        String sql = "SELECT COUNT(*) as total FROM barang";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getTotalStokBarang() {
        String sql = "SELECT COALESCE(SUM(stok), 0) as total FROM barang";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getJumlahBarangStokRendah(int batas) {
        String sql = "SELECT COUNT(*) as total FROM barang WHERE stok < ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, batas);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getTotalTransaksiMasuk(Date dari, Date sampai) {
        String sql = "SELECT COUNT(*) as total FROM barang_masuk WHERE tanggal_masuk BETWEEN ? AND ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getTotalTransaksiKeluar(Date dari, Date sampai) {
        String sql = "SELECT COUNT(*) as total FROM barang_keluar WHERE tanggal_keluar BETWEEN ? AND ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getTotalProduksi(Date dari, Date sampai) {
        String sql = "SELECT COUNT(*) as total FROM produksi WHERE tanggal_produksi BETWEEN ? AND ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, new java.sql.Date(dari.getTime()));
            ps.setDate(2, new java.sql.Date(sampai.getTime()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public int getTotalDistributor() {
        String sql = "SELECT COUNT(*) as total FROM distributor";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return rs.getInt("total");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}