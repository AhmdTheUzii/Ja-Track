package com.JaTrack.dao;

import com.JaTrack.model.Produksi;
import com.JaTrack.model.DetailProduksi;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ProduksiDAO {
    
    private Connection conn;
    
    public ProduksiDAO(Connection conn) {
        this.conn = conn;
    }
    
    /**
     * INSERT Produksi + Detail + AUTO UPDATE STOK BARANG
     * Menggunakan TRANSACTION untuk memastikan data konsisten
     */
    public boolean insert(Produksi produksi) {
        String sqlProduksi = "INSERT INTO produksi (tanggal_produksi, hasil_produksi, keterangan) VALUES (?, ?, ?)";
        String sqlDetail = "INSERT INTO detail_produksi (id_produksi, id_barang, nama_barang, jumlah_digunakan, satuan) VALUES (?, ?, ?, ?, ?)";
        String sqlUpdateStok = "UPDATE barang SET stok = stok - ? WHERE id_barang = ?";
        
        try {
            // Mulai TRANSACTION
            conn.setAutoCommit(false);
            
            // 1. Insert master produksi
            PreparedStatement psProduksi = conn.prepareStatement(sqlProduksi, Statement.RETURN_GENERATED_KEYS);
            psProduksi.setDate(1, new java.sql.Date(produksi.getTanggalProduksi().getTime()));
            psProduksi.setString(2, produksi.getHasilProduksi());
            psProduksi.setString(3, produksi.getKeterangan());
            
            int result = psProduksi.executeUpdate();
            
            if (result > 0) {
                // Ambil ID produksi yang baru di-insert
                ResultSet rs = psProduksi.getGeneratedKeys();
                int idProduksi = 0;
                if (rs.next()) {
                    idProduksi = rs.getInt(1);
                }
                
                // 2. Insert detail bahan + Update stok
                PreparedStatement psDetail = conn.prepareStatement(sqlDetail);
                PreparedStatement psUpdateStok = conn.prepareStatement(sqlUpdateStok);
                
                for (DetailProduksi detail : produksi.getDetailBahan()) {
                    // Insert detail
                    psDetail.setInt(1, idProduksi);
                    psDetail.setInt(2, detail.getIdBarang());
                    psDetail.setString(3, detail.getNamaBarang());
                    psDetail.setInt(4, detail.getJumlahDigunakan());
                    psDetail.setString(5, detail.getSatuan());
                    psDetail.executeUpdate();
                    
                    // Update stok barang (KURANGI)
                    psUpdateStok.setInt(1, detail.getJumlahDigunakan());
                    psUpdateStok.setInt(2, detail.getIdBarang());
                    psUpdateStok.executeUpdate();
                }
                
                // COMMIT transaction jika semua berhasil
                conn.commit();
                conn.setAutoCommit(true);
                return true;
            }
            
            conn.rollback();
            conn.setAutoCommit(true);
            return false;
            
        } catch (SQLException e) {
            try {
                // ROLLBACK jika ada error
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null, "Error Insert Produksi: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * READ - Ambil semua produksi
     */
    public List<Produksi> getAll() {
        List<Produksi> list = new ArrayList<>();
        String sql = "SELECT * FROM produksi ORDER BY id_produksi DESC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Produksi produksi = new Produksi();
                produksi.setIdProduksi(rs.getInt("id_produksi"));
                produksi.setTanggalProduksi(rs.getDate("tanggal_produksi"));
                produksi.setHasilProduksi(rs.getString("hasil_produksi"));
                produksi.setKeterangan(rs.getString("keterangan"));
                list.add(produksi);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get All: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * READ - Ambil detail bahan berdasarkan ID Produksi
     */
    public List<DetailProduksi> getDetailByIdProduksi(int idProduksi) {
        List<DetailProduksi> list = new ArrayList<>();
        String sql = "SELECT * FROM detail_produksi WHERE id_produksi = ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idProduksi);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                DetailProduksi detail = new DetailProduksi();
                detail.setIdDetail(rs.getInt("id_detail"));
                detail.setIdProduksi(rs.getInt("id_produksi"));
                detail.setIdBarang(rs.getInt("id_barang"));
                detail.setNamaBarang(rs.getString("nama_barang"));
                detail.setJumlahDigunakan(rs.getInt("jumlah_digunakan"));
                detail.setSatuan(rs.getString("satuan"));
                list.add(detail);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get Detail: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * DELETE - Hapus produksi + KEMBALIKAN STOK BARANG
     */
    public boolean delete(int idProduksi) {
        String sqlGetDetail = "SELECT id_barang, jumlah_digunakan FROM detail_produksi WHERE id_produksi = ?";
        String sqlDeleteProduksi = "DELETE FROM produksi WHERE id_produksi = ?";
        String sqlRestoreStok = "UPDATE barang SET stok = stok + ? WHERE id_barang = ?";
        
        try {
            conn.setAutoCommit(false);
            
            // 1. Ambil detail bahan untuk restore stok
            PreparedStatement psGetDetail = conn.prepareStatement(sqlGetDetail);
            psGetDetail.setInt(1, idProduksi);
            ResultSet rs = psGetDetail.executeQuery();
            
            List<int[]> detailList = new ArrayList<>();
            while (rs.next()) {
                int[] detail = new int[2];
                detail[0] = rs.getInt("id_barang");
                detail[1] = rs.getInt("jumlah_digunakan");
                detailList.add(detail);
            }
            
            // 2. Restore stok barang (TAMBAHKAN KEMBALI)
            PreparedStatement psRestore = conn.prepareStatement(sqlRestoreStok);
            for (int[] detail : detailList) {
                psRestore.setInt(1, detail[1]); // jumlah
                psRestore.setInt(2, detail[0]); // id_barang
                psRestore.executeUpdate();
            }
            
            // 3. Delete produksi (detail otomatis terhapus karena CASCADE)
            PreparedStatement psDelete = conn.prepareStatement(sqlDeleteProduksi);
            psDelete.setInt(1, idProduksi);
            int result = psDelete.executeUpdate();
            
            conn.commit();
            conn.setAutoCommit(true);
            return result > 0;
            
        } catch (SQLException e) {
            try {
                conn.rollback();
                conn.setAutoCommit(true);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            JOptionPane.showMessageDialog(null, "Error Delete: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * SEARCH - Cari produksi
     */
    public List<Produksi> search(String keyword) {
        List<Produksi> list = new ArrayList<>();
        String sql = "SELECT * FROM produksi WHERE hasil_produksi LIKE ? OR keterangan LIKE ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Produksi produksi = new Produksi();
                produksi.setIdProduksi(rs.getInt("id_produksi"));
                produksi.setTanggalProduksi(rs.getDate("tanggal_produksi"));
                produksi.setHasilProduksi(rs.getString("hasil_produksi"));
                produksi.setKeterangan(rs.getString("keterangan"));
                list.add(produksi);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Search: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * Cek stok barang sebelum produksi
     */
    public boolean cekStok(int idBarang, int jumlahDibutuhkan) {
        String sql = "SELECT stok FROM barang WHERE id_barang = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idBarang);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int stokSekarang = rs.getInt("stok");
                return stokSekarang >= jumlahDibutuhkan;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}