package com.JaTrack.dao;

import com.JaTrack.model.Distributor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 * DAO (Data Access Object) untuk CRUD Distributor
 * DAO ini yang ngurus semua komunikasi dengan database
 */
public class DistributorDAO {
    
    private Connection conn;
    
    public DistributorDAO(Connection conn) {
        this.conn = conn;
    }
    
    // CREATE - Tambah distributor
    public boolean insert(Distributor distributor) {
        String sql = "INSERT INTO distributor (nama_distributor, alamat, no_telepon, kontak_person, jenis_barang) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, distributor.getNamaDistributor());
            ps.setString(2, distributor.getAlamat());
            ps.setString(3, distributor.getNoTelepon());
            ps.setString(4, distributor.getKontakPerson());
            ps.setString(5, distributor.getJenisBarang());
            
            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Insert: " + e.getMessage());
            return false;
        }
    }
    
    // READ - Ambil semua distributor
    public List<Distributor> getAll() {
        List<Distributor> list = new ArrayList<>();
        String sql = "SELECT * FROM distributor ORDER BY id_distributor DESC";
        
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Distributor distributor = new Distributor();
                distributor.setIdDistributor(rs.getInt("id_distributor"));
                distributor.setNamaDistributor(rs.getString("nama_distributor"));
                distributor.setAlamat(rs.getString("alamat"));
                distributor.setNoTelepon(rs.getString("no_telepon"));
                distributor.setKontakPerson(rs.getString("kontak_person"));
                distributor.setJenisBarang(rs.getString("jenis_barang"));
                list.add(distributor);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Get All: " + e.getMessage());
        }
        return list;
    }
    
    // UPDATE - Update distributor
    public boolean update(Distributor distributor) {
        String sql = "UPDATE distributor SET nama_distributor=?, alamat=?, no_telepon=?, kontak_person=?, jenis_barang=? WHERE id_distributor=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, distributor.getNamaDistributor());
            ps.setString(2, distributor.getAlamat());
            ps.setString(3, distributor.getNoTelepon());
            ps.setString(4, distributor.getKontakPerson());
            ps.setString(5, distributor.getJenisBarang());
            ps.setInt(6, distributor.getIdDistributor());
            
            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Update: " + e.getMessage());
            return false;
        }
    }
    
    // DELETE - Hapus distributor
    public boolean delete(int idDistributor) {
        String sql = "DELETE FROM distributor WHERE id_distributor=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idDistributor);
            int result = ps.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Delete: " + e.getMessage());
            return false;
        }
    }
    
    // SEARCH - Cari distributor
    public List<Distributor> search(String keyword) {
        List<Distributor> list = new ArrayList<>();
        String sql = "SELECT * FROM distributor WHERE nama_distributor LIKE ? OR alamat LIKE ? OR kontak_person LIKE ? OR jenis_barang LIKE ?";
        
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            String key = "%" + keyword + "%";
            ps.setString(1, key);
            ps.setString(2, key);
            ps.setString(3, key);
            ps.setString(4, key);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Distributor distributor = new Distributor();
                distributor.setIdDistributor(rs.getInt("id_distributor"));
                distributor.setNamaDistributor(rs.getString("nama_distributor"));
                distributor.setAlamat(rs.getString("alamat"));
                distributor.setNoTelepon(rs.getString("no_telepon"));
                distributor.setKontakPerson(rs.getString("kontak_person"));
                distributor.setJenisBarang(rs.getString("jenis_barang"));
                list.add(distributor);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error Search: " + e.getMessage());
        }
        return list;
    }
}